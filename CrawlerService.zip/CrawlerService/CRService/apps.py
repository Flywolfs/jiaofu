from django.apps import AppConfig


class CRServiceConfig(AppConfig):
    name = 'CRService'
