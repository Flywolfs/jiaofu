"""
    Handles miscellaneous image processing tasks
"""
# TODO: parameters should not be specified using global config file. Instead should be handled by Rec_config for each
#       document class.

import cv2
import numpy as np
from PIL import Image


def __angle_cos(p0, p1, p2):
    """
        Calculate the cosine of the angle between vector p0-p1 and p1-p2

    :param p0:
    :param p1:
    :param p2:
    :return: cosine of the angle between vector p0-p1 and p1-p2
    """
    d1, d2 = (p0 - p1).astype('float'), (p2 - p1).astype('float')
    return abs(np.dot(d1, d2) / np.sqrt(np.dot(d1, d1) * np.dot(d2, d2)))


def extract_grid_for_reg(img, min_area, v_kernel_ratio, h_kernel_ratio):
    """
        internal method that thickens the detected grid lines for better registration results

    :param img: numpy array, opencv GRAYSCALE image object
    :param min_area: The smallest area for which a
    :param v_kernel_ratio: The ratio which determines the size of the vertical erosion kernel. larger value gives
    smaller kernel
    :param h_kernel_ratio: The ratio which determines the size of the horizontal erosion kernel. larger value gives
    smaller kernel
    :return:
    """
    # performs smoothing first incase deskewing makes chopping lines
    # dst = cv2.filter2D(img,-1,kernel)
    smooth_kernel = np.ones((5, 5), np.float32) / 25
    img = cv2.filter2D(img, -1, smooth_kernel)

    v_kernel_length = img.shape[1] // v_kernel_ratio
    h_kernel_length = img.shape[0] // h_kernel_ratio

    # performs closing on horizontal and vertical directions to obtain line segments of each direction
    hori_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (v_kernel_length, 1))
    vert_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, h_kernel_length))
    horizontal_lines_img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, hori_kernel)
    vertical_lines_img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, vert_kernel)

    # overlay the two images
    img_final_bin = cv2.addWeighted(vertical_lines_img, 0.5, horizontal_lines_img, 0.5, 0.0)

    squares = []
    for gray in cv2.split(img_final_bin):
        # try various thresholds, 10 iterations, maybe overkill?
        for thrs in range(0, 255, 26):
            if thrs == 0:
                img_bin = cv2.Canny(gray, 0, 50, apertureSize=5)
                img_bin = cv2.dilate(img_bin, None)
            else:
                _retval, img_bin = cv2.threshold(gray, thrs, 255, cv2.THRESH_BINARY_INV)

            # finds too many contours!
            bin, contours, _hierarchy = cv2.findContours(img_bin, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

            for cnt in contours:
                cnt_len = cv2.arcLength(cnt, True)
                cnt = cv2.approxPolyDP(cnt, epsilon=0.02 * cnt_len, closed=True)

                if len(cnt) == 4 and cv2.contourArea(cnt) > min_area and cv2.isContourConvex(cnt):
                    cnt = cnt.reshape(-1, 2)
                    max_cos = np.max([__angle_cos(cnt[i], cnt[(i + 1) % 4], cnt[(i + 2) % 4]) for i in range(4)])
                    if max_cos < 0.1:
                        x, y, w, h = cv2.boundingRect(cnt)
                        squares.append((x, y, w, h))

    for val in squares:
        cv2.rectangle(img_final_bin, (val[0], val[1]), (val[0] + val[2], val[1] + val[3]), color=(0, 0, 0),
                      thickness=10)

        # do denoise (erosion) again to obtain image with only grid ?

    return img_final_bin


def box_extraction(img, min_area, v_kernel_ratio, h_kernel_ratio):
    """
        finds rectangles by intersecting vertical and horizontal lines... currently not the smartest way of determining

    kernel length
    :param img: opencv GRAYSCALE, inversely-binarized image (Numpy array), the image from which we will find the boxes
    :param min_area: int, the lower limit of area, smaller than which a contour will not be included in the results
    :param v_kernel_ratio: The ratio which determines the size of the vertical erosion kernel. larger value gives
    smaller kernel
    :param h_kernel_ratio: The ratio which determines the size of the horizontal erosion kernel. larger value gives
    smaller kernel
    :return: The list of detected rectangles in the image, in (x,y,w,h) format and The processed image from which we
    extracted the rectangles
    """

    # remove noise
    # kernel = np.ones((1,1),np.uint8)
    # img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, kernel)
    # dilate_kernel = np.ones((1,1),np.uint8)
    # img = cv2.dilate(img, dilate_kernel, iterations=1)

    h_kernel_length = img.shape[1] // h_kernel_ratio
    v_kernel_length = img.shape[0] // v_kernel_ratio

    # performs closing on horizontal and vertical directions to obtain line segments of each direction
    hori_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (h_kernel_length, 1))
    vert_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, v_kernel_length))
    horizontal_lines_img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, hori_kernel)
    vertical_lines_img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, vert_kernel)

    # overlay the two images
    img_final_bin = cv2.addWeighted(vertical_lines_img, 0.5, horizontal_lines_img, 0.5, 0.0)

    squares = []
    for gray in cv2.split(img_final_bin):
        # try various thresholds, 10 iterations, maybe overkill?
        for thrs in range(0, 255, 26):
            if thrs == 0:
                img_bin = cv2.Canny(gray, 0, 50, apertureSize=5)
                img_bin = cv2.dilate(img_bin, None)
            else:
                _retval, img_bin = cv2.threshold(gray, thrs, 255, cv2.THRESH_BINARY_INV)

            # finds too many contours!
            bin, contours, _hierarchy = cv2.findContours(img_bin, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

            for cnt in contours:
                cnt_len = cv2.arcLength(cnt, True)
                cnt = cv2.approxPolyDP(cnt, epsilon=0.02 * cnt_len, closed=True)

                if len(cnt) == 4 and cv2.contourArea(cnt) > min_area and cv2.isContourConvex(cnt):
                    cnt = cnt.reshape(-1, 2)
                    max_cos = np.max([__angle_cos(cnt[i], cnt[(i + 1) % 4], cnt[(i + 2) % 4]) for i in range(4)])
                    if max_cos < 0.1:
                        x, y, w, h = cv2.boundingRect(cnt)
                        squares.append((x, y, w, h))

    squares = sorted(squares, key=lambda box: (box[0], box[1]))
    return squares, img_final_bin


def grid_extraction(img, min_area, v_kernel_ratio, h_kernel_ratio):
    """
        process a given image and return only the grid lines on the image. Basic process is similar to box_extraction,
    but less harsh on the image to avoid impact on OCR results

    :param img: opencv GRAYSCALE, inversely-binarized image (Numpy array), the image from which we will find the grid
    lines
    :param min_area: int, the lower limit of area, smaller than which a contour will not be included in the results
    :param v_kernel_ratio: The ratio which determines the size of the vertical erosion kernel. larger value gives
    smaller kernel
    :param h_kernel_ratio: The ratio which determines the size of the horizontal erosion kernel. larger value gives
    smaller kernel
    :return: opencv image, an image contains the grid lines on the original image
    """

    # performs smoothing first in case deskewing makes jagged lines
    smooth_kernel = np.ones((5,5),np.float32)/25
    img = cv2.filter2D(img,-1,smooth_kernel)

    h_kernel_length = img.shape[1] // h_kernel_ratio
    v_kernel_length = img.shape[0] // v_kernel_ratio

    # performs closing on horizontal and vertical directions to obtain line segments of each direction
    hori_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (h_kernel_length, 1))
    vert_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, v_kernel_length))
    horizontal_lines_img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, hori_kernel)
    vertical_lines_img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, vert_kernel)

    # overlay the two images
    img_final_bin = cv2.addWeighted(vertical_lines_img, 0.5, horizontal_lines_img, 0.5, 0.0)

    squares = []
    for gray in cv2.split(img_final_bin):
        # try various thresholds, 10 iterations, maybe overkill?
        for thrs in range(0, 255, 26):
            if thrs == 0:
                img_bin = cv2.Canny(gray, 0, 50, apertureSize=5)
                img_bin = cv2.dilate(img_bin, None)
            else:
                _retval, img_bin = cv2.threshold(gray, thrs, 255, cv2.THRESH_BINARY_INV)

            # finds too many contours!
            bin, contours, _hierarchy = cv2.findContours(img_bin, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

            for cnt in contours:
                cnt_len = cv2.arcLength(cnt, True)
                cnt = cv2.approxPolyDP(cnt, epsilon=0.02 * cnt_len, closed=True)

                if len(cnt) == 4 and cv2.contourArea(cnt) > min_area and cv2.isContourConvex(cnt):
                    cnt = cnt.reshape(-1, 2)
                    max_cos = np.max([__angle_cos(cnt[i], cnt[(i + 1) % 4], cnt[(i + 2) % 4]) for i in range(4)])
                    if max_cos < 0.1:
                        x, y, w, h = cv2.boundingRect(cnt)
                        squares.append((x, y, w, h))

    for val in squares:
        cv2.rectangle(img_final_bin, (val[0], val[1]), (val[0] + val[2], val[1] + val[3]), color=(0, 0, 0), thickness=5)

    return img_final_bin


def crop_border(img, width=5):
    """
        shaves a fixed number of pixels from the given image

    :param img: opencv image (Numpy array), the image from which we will shave the border
    :param width: the number of pixel to be shaved off from each side of the image
    :return: The 'clean-shaved' image
    """

    return img[width:-1 * width, width:-1 * width]


def pad_img(img, width=10, color=(0, 0, 0)):
    """
        adds a fixed width border to the given img

    :param img: numpy 2d array, the image to be altered
    :param width: int, the width of the border in pixels
    :param color: the color of the border in (b,g,r) format, default to white
    :return: the padded image
    """

    padded_img = cv2.copyMakeBorder(img, width, width, width, width, cv2.BORDER_CONSTANT, value=color)

    return padded_img


def resize_pil(img, ratio):
    """
        Resize a PIL image by the given ratio
    :param img: PIL Image object, the image to be resized
    :param ratio: int/float. the ratio to resize the image by
    :return: the resized image
    """
    hsize = int((float(img.size[1])*float(ratio)))
    wsize = int((float(img.size[0])*float(ratio)))
    img = img.resize((wsize, hsize), Image.LINEAR)
    return img


def resize_cv2(img, ratio):
    """
        Resize a opencv image by the given ratio
    :param img: opencv image object (numpy array), the image to be resized
    :param ratio: int/float. the ratio to resize the image by
    :return:
    """
    img = cv2.resize(img, fx=ratio, fy=ratio, dsize=(0, 0))
    return img


def exp_box_extraction(img, min_area, v_kernel_ratio, h_kernel_ratio):
    """
        experimental method aimed at helping template building in the future, extracts box location from clean box image,
    returns less boxes, stability needs testing.

    :param img: opencv GRAYSCALE, inversely-binarized image (Numpy array), the image from which we will find the boxes
    :param min_area: int, the lower limit of area, smaller than which a contour will not be included in the results
    :param v_kernel_ratio: The ratio which determines the size of the vertical erosion kernel. larger value gives
    smaller kernel
    :param h_kernel_ratio: The ratio which determines the size of the horizontal erosion kernel. larger value gives
    smaller kernel
    :return: The list of detected rectangles in the image, in (x,y,w,h) format and The processed image from which we
    extracted the rectangles
    """
    H, W = img.shape
    h_kernel_length = img.shape[1] // h_kernel_ratio
    v_kernel_length = img.shape[0] // v_kernel_ratio

    # performs closing on horizontal and vertical directions to obtain line segments of each direction
    hori_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (h_kernel_length, 1))
    vert_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, v_kernel_length))
    horizontal_lines_img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, hori_kernel)
    vertical_lines_img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, vert_kernel)

    # overlay the two images
    img_final_bin = cv2.addWeighted(vertical_lines_img, 0.5, horizontal_lines_img, 0.5, 0.0)

    # do find contour for the first time, finds box on current image
    squares = []
    for gray in cv2.split(img_final_bin):
        # try various thresholds, 10 iterations, maybe overkill?
        for thrs in range(0, 255, 26):
            if thrs == 0:
                img_bin = cv2.Canny(gray, 0, 50, apertureSize=5)
                img_bin = cv2.dilate(img_bin, None)
            else:
                _retval, img_bin = cv2.threshold(gray, thrs, 255, cv2.THRESH_BINARY_INV)

            # finds too many contours!
            _, contours, hierarchy = cv2.findContours(img_bin, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
            if hierarchy is None:
                continue
            hierarchy = hierarchy[0]
            # sieve through contour, find only internal ones
            holes = []
            for i in range(len(contours)):
                if hierarchy[i][3] >= 0:
                    holes.append(contours[i])

            for cnt in holes:
                cnt_len = cv2.arcLength(cnt, True)
                cnt = cv2.approxPolyDP(cnt, epsilon=0.02 * cnt_len, closed=True)

                if len(cnt) == 4 and cv2.contourArea(cnt) > min_area and cv2.isContourConvex(cnt):
                    cnt = cnt.reshape(-1, 2)
                    max_cos = np.max([__angle_cos(cnt[i], cnt[(i + 1) % 4], cnt[(i + 2) % 4]) for i in range(4)])
                    if max_cos < 0.1:
                        x, y, w, h = cv2.boundingRect(cnt)
                        squares.append((x, y, w, h))

    # makes a blank image with original shape and draw exaggerated boxes on it.
    img_copy = np.zeros(img_final_bin.shape, np.uint8)
    for val in squares:
        cv2.rectangle(img_copy, (val[0], val[1]), (val[0] + val[2], val[1] + val[3]), color=(255, 255, 255),
                      thickness=5)

        # do box finding for a second time
    squares = []
    _, contours, hierarchy = cv2.findContours(img_copy, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    if hierarchy is None:
        return []
    hierarchy = hierarchy[0]
    # sieve through contour, find only internal ones
    holes = []
    for i in range(len(contours)):
        if hierarchy[i][3] >= 0:
            holes.append(contours[i])

    for cnt in holes:
        cnt_len = cv2.arcLength(cnt, True)
        cnt = cv2.approxPolyDP(cnt, epsilon=0.02 * cnt_len, closed=True)

        if len(cnt) == 4 and cv2.contourArea(cnt) > min_area and cv2.isContourConvex(cnt):
            cnt = cnt.reshape(-1, 2)
            max_cos = np.max([__angle_cos(cnt[i], cnt[(i + 1) % 4], cnt[(i + 2) % 4]) for i in range(4)])
            if max_cos < 0.1:
                x, y, w, h = cv2.boundingRect(cnt)
                # do not include the bounding box for the entire page!
                if w * h < 0.8 * W * H:
                    squares.append((x, y, w, h))
    # sorts in two priorities: Ascending x-coordinates and ascending y-coordinates (i.e. reading direction)
    squares = sorted(squares, key=lambda box: (box[0], box[1]))

    return squares


def exp_extract_grid(img, min_area, v_kernel_ratio, h_kernel_ratio):
    """
        process a given image and return only the grid lines on the image. Basic process is similar to box_extraction,
    but less harsh on the image to avoid impact on OCR results

    :param img: opencv GRAYSCALE, inversely-binarized image (Numpy array), the image from which we will find the grid
    lines
    :param min_area: int, the lower limit of area, smaller than which a contour will not be included in the results
    :param v_kernel_ratio: The ratio which determines the size of the vertical erosion kernel. larger value gives
    smaller kernel
    :param h_kernel_ratio: The ratio which determines the size of the horizontal erosion kernel. larger value gives
    smaller kernel
    :return: opencv image, an image contains the grid lines on the original image (black on white)
    """

    # performs smoothing first incase deskewing makes jagged lines
    smooth_kernel = np.ones((5,5),np.float32)/25
    img = cv2.filter2D(img,-1,smooth_kernel)

    h_kernel_length = img.shape[1] // h_kernel_ratio
    v_kernel_length = img.shape[0] // v_kernel_ratio

    # performs closing on horizontal and vertical directions to obtain line segments of each direction
    hori_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (h_kernel_length, 1))
    vert_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, v_kernel_length))
    horizontal_lines_img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, hori_kernel)
    vertical_lines_img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, vert_kernel)

    # overlay the two images
    img_final_bin = cv2.addWeighted(vertical_lines_img, 0.5, horizontal_lines_img, 0.5, 0.0)

    squares = []
    for gray in cv2.split(img_final_bin):
        # try various thresholds, 10 iterations, maybe overkill?
        for thrs in range(0, 255, 26):
            if thrs == 0:
                img_bin = cv2.Canny(gray, 0, 50, apertureSize=5)
                img_bin = cv2.dilate(img_bin, None)
            else:
                _retval, img_bin = cv2.threshold(gray, thrs, 255, cv2.THRESH_BINARY_INV)

            # finds too many contours!
            bin, contours, _hierarchy = cv2.findContours(img_bin, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

            for cnt in contours:
                cnt_len = cv2.arcLength(cnt, True)
                cnt = cv2.approxPolyDP(cnt, epsilon=0.02 * cnt_len, closed=True)

                if len(cnt) == 4 and cv2.contourArea(cnt) > min_area and cv2.isContourConvex(cnt):
                    cnt = cnt.reshape(-1, 2)
                    max_cos = np.max([__angle_cos(cnt[i], cnt[(i + 1) % 4], cnt[(i + 2) % 4]) for i in range(4)])
                    if max_cos < 0.1:
                        x, y, w, h = cv2.boundingRect(cnt)
                        squares.append((x, y, w, h))

    img_copy = np.zeros(img_final_bin.shape, np.uint8)
    for val in squares:
        cv2.rectangle(img_copy, (val[0], val[1]), (val[0] + val[2], val[1] + val[3]), color=(255, 255, 255),
                      thickness=10)

    _, img_copy = cv2.threshold(img_copy, 128, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
    return img_copy


def pad_to_square(img, size=50):
    """
        pads a given image to square with given border size

    :param img:
    :param size:
    :return:
    """
    old_size = img.shape[:2] # old_size is in (height, width) format

    ratio = float(size)/max(old_size)
    new_size = tuple([int(x*ratio) for x in old_size])

    # new_size should be in (width, height) format

    img = cv2.resize(img, (new_size[1], new_size[0]))

    delta_w = size - new_size[1]
    delta_h = size - new_size[0]
    top, bottom = delta_h//2, delta_h-(delta_h//2)
    left, right = delta_w//2, delta_w-(delta_w//2)

    color = [0, 0, 0]
    new_img = cv2.copyMakeBorder(img, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color)

    return new_img


def intersection_over_union(detected, template):
    """
        Calculate the Intersection over Union ratio of two given rectangles

    :param detected: numpy array, The first rectangle, in (x,y,w,h) format
    :param template: numpy array, The other rectangle, in (x,y,w,h) format
    :return: numpy float32, The calculated IOU
    """

    top = max(detected[1], template[1])
    left = max(detected[0], template[0])
    bottom = min(detected[1] + detected[3], template[1] + template[3])
    right = min(detected[0] + detected[2], template[0] + template[2])

    # compute the area of intersection rectangle
    interArea = max(0, right - left + 1) * max(0, bottom - top + 1)
    detected_area = detected[2] * detected[3]
    template_area = template[2] * template[3]

    # compute the intersection over union
    iou = interArea / np.float32(detected_area + template_area - interArea)

    # return the intersection over union value
    return iou


def non_max_suppression(boxes, thresh):
    """
        Performs non-maximal suppression on list of rois
    :param boxes: list, list of rois in (x,y,w,h) format
    :param thresh: float, the threshold of area of intersection of an roi over area of a saved roi, above which the roi
                    will be removed
    :return: list of "cleaned" rois
    """
    # if there are no boxes, return an empty list
    if len(boxes) == 0:
        return []

    # convert to array for easier manipulation
    boxes = np.array(boxes)
    # list of picked indexes
    result = []

    # grab the coordinates of the bounding boxes
    x1 = boxes[:, 0]
    y1 = boxes[:, 1]
    w = boxes[:, 2]
    h = boxes[:, 3]
    x2 = x1 + w
    y2 = y1 + h

    # area of the bounding boxes
    area = (x2 - x1 + 1) * (y2 - y1 + 1)
    # sort the boxes by their lower y-coordinates
    idxs = np.argsort(y2)

    while len(idxs) > 0:
        # save the last roi in the list
        last = len(idxs) - 1
        i = idxs[last]
        result.append(i)

        # find the largest (x, y) coordinates for the start of the roi and the smallest (x, y) coordinates
        # for the end of the roi
        xx1 = np.maximum(x1[i], x1[idxs[:last]])
        yy1 = np.maximum(y1[i], y1[idxs[:last]])
        xx2 = np.minimum(x2[i], x2[idxs[:last]])
        yy2 = np.minimum(y2[i], y2[idxs[:last]])

        # compute the width and height of the roi
        w = np.maximum(0, xx2 - xx1 + 1)
        h = np.maximum(0, yy2 - yy1 + 1)

        # compute the ratio of overlap
        overlap = (w * h) / area[idxs[:last]]

        # delete all roi from the list that have ratio of overlap > threshold
        idxs = np.delete(idxs, np.concatenate(([last],
                                               np.where(overlap > thresh)[0])))

    mask = np.ones(len(boxes), np.bool)
    mask[result] = 0
    return boxes[mask]


def box_distance(box_1, box_2):
    """
            finds euclidean distance between the center point of the two given boxes, which are both in (x,y,w,h) format
    :param box_1: tuple, the box coordinates in (x,y,w,h) format
    :param box_2: tuple, the box coordinates in (x,y,w,h) format
    :return: the calculated euclidean distance
    """
    pt1 = np.array([box_1[0] + box_1[2] / 2.0, box_1[1] + box_1[3] / 2.0])
    pt2 = np.array([box_2[0] + box_2[2] / 2.0, box_2[1] + box_2[3] / 2.0])

    return np.linalg.norm(pt1 - pt2)