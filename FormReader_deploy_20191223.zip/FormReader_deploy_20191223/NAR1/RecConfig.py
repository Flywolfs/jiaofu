import os
import string

PWD = os.getcwd()

# calculated ratio = 0.0986740672217083, 0.07 seems to give the most consistent results
CHECK_RATIO = 0.07

UPPER_LATIN_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
LOWER_LATIN_ALPHABET = 'abcdefghijklmnopqrstuvwxyz'
# This is NOT overkill, belive it or not...
# TODO: complete the list for all utf-8 punctuations
PUNCTUATION = r'+-_*^&%$#@！～`<>,.|\'\"’﹌[]()ˊˇ‥ˍ﹎﹣﹝﹞﹐˙‧′ˉ﹡=，﹒。…〝"“”～~-【】'+string.punctuation
DIGITS = '0123456789'
# HKID whitelist for the first two characters
HKID_CHAR = r'CPEHFZBDRKGYZVAUWN'

# parameter when doing feature finding for source images
MAX_FEATURES = 20000
# Lowe's ratio test parameter for feature matching
LOWE_RATIO = 0.7

# parameter when creating template
# MAX_TEMPLATE_FEATURES = 100000000

# cut off for the IOU value
ROI_CUTOFF_RATIO = 0.2

COORD_REGEX = r'{"name":"rect","x":(\d+),"y":(\d+),"width":(\d+),"height":(\d+)}'
LABEL_REGEX = r'{"Label":"([\s\S]+)"}'
PG_REGEX = r'NAR1-(\d+).png'


# Segmentation.py

# open kernel size for line segmentation
LINE_OPEN_KERNEL_SIZE = 3
# open kernel size for paragraph/ text block segmentation
PARA_OPEN_KERNEL_SIZE = 5
# dilation kernel size for character segmentation
CHAR_DILATE_KERNEL_SIZE = 5
# Smallest line height
LOWER_LW_LIMIT = 10
# Smallest character width
LOWER_CW_LIMIT = 10
# Smallest paragraph height
LOWER_PW_LIMIT = 100

# Imgproc.py
# the lower limit of area, smaller than which a contour will not be included in the results
BOX_MIN_AREA = 1000
# The ratio which determines the size of the vertical erosion kernel. larger value gives
# smaller kernel
BOX_V_KERNEL_RATIO = 120
# The ratio which determines the size of the horizontal erosion kernel. larger value gives
# smaller kernel
BOX_H_KERNEL_RATIO = 120
# The ratio which determines the size of the vertical erosion kernel. larger value gives
# smaller kernel
GRID_V_KERNEL_RATIO = 70
# The ratio which determines the size of the horizontal erosion kernel. larger value gives
# smaller kernel
GRID_H_KERNEL_RATIO = 40

# PDF conversion settings
DPI = 300

# Template paths
NEW_TEMPLATE_PATH = 'NAR1/ROI_template/'
OLD_TEMPLATE_PATH = 'NAR1/ROI_template_old/'
WEB_TEMPLATE_PATH = 'NAR1/ROI_template_web/'

# tess_config paths
EN_TESS_CONFIG_PATH = 'NAR1/tess_settings.csv'
CN_TESS_CONFIG_PATH = 'NAR1/tess_settings.csv'
