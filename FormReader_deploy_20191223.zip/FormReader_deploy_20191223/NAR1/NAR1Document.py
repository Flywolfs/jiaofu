"""
    class file for NAR1 document, handles Document level functions
"""
import os
import os.path as osp
import re
import json
import cv2
import numpy as np
import pandas as pd
from pdf2image import convert_from_path
from pdf2image.exceptions import PDFPageCountError, PDFInfoNotInstalledError, PDFSyntaxError

from NAR1.MatchTemplate import match_template_hist
from NAR1.PageRecognition import rec_document
from NAR1.RecConfig import DPI, NEW_TEMPLATE_PATH, OLD_TEMPLATE_PATH, WEB_TEMPLATE_PATH
from json2html import json2html


class PDFReadError(Exception):
    # needed since the error message of pdf2image is so cryptic, we return them bundled as read error instead
    pass


class ResultWriteError(Exception):
    # acknowledges any failure in writing out the recognition reuslts and delegates handling to api instead of
    # crashing
    pass


class NAR1Document:

    def __init__(self, input_path, output_path):
        """
            Initializes the NAR1 object, one object should be created for each pdf
        :param input_path: String, points to the pdf file
        :param output_path: String, path to the output folder
        """
        # Do type checks here!
        print(input_path)
        self.INPUT_PATH = input_path
        self.OUTPUT_PATH = output_path

    def recognize(self):
        """
            extract information from the given pdf file and outputs to specified path
        :return: None
        """
        pages = self.__parse_input()
        result = self.__extract_data(pages)
        self.__output(result, self.OUTPUT_PATH)
        return

    def __parse_input(self):
        """
            reads in the pdf at the specified path, and return a list of images scanned from the pdf
        :return: None
        :raises PDFReadError: when pdf file cannot be read for whatever reason
        """
        try:
            pages = convert_from_path(self.INPUT_PATH, dpi=DPI)
        except (PDFPageCountError, PDFInfoNotInstalledError, PDFSyntaxError):
            raise PDFReadError('The given pdf cannot be correctly read!')
        '''
        # do PIL sharpening for all pages here
        for page in pages:
            try:
                page = page.filter(ImageFilter.SHARPEN)
            except ValueError:
                pass  # skip filtering for images that does not support it
        '''
        return pages

    def __extract_data(self, pages):
        """
            parent function for the actual OCR process, split up the pages and then pass to page-level
        :param pages:
        :return:
        """
        path, templates = self.__match_template(pages[0])
        # Note: WEB_TEMPLATE_PATH does not support now!
        if path == WEB_TEMPLATE_PATH:
            return {}
        lang = 'E'
        result = rec_document(pages, templates, path, lang)
        return result

    def __output(self, result, outpath):
        """
            writes the recognition output to file, currently writing to txt for easier error checks
        :param result: string, the recognition results
        :param outpath: string, the specified output path
        :raise CSVWriteError: when encounters failure in writing out the results
        :return: None
        :raises CSVWriteError: when writing result failed for whatever reason
        """
        pdf_name = osp.splitext(osp.split(self.INPUT_PATH)[-1])[0]
        fname = osp.join(outpath, "{}.json".format(pdf_name))
        fhtml = osp.join(outpath, "{}.html".format(pdf_name))
        try:
            with open(fname, 'w') as out_file:
                json.dump(dict(result), out_file, ensure_ascii=False, indent=2)

            with open(fhtml, 'w') as out_file:
                html = json2html.convert(json.dumps(dict(result), ensure_ascii=False))
                out_file.write(html)
        except IOError:
            raise ResultWriteError('Writing results to file failed')
        return

    def __match_template(self, img):
        """
            Uses histogram comparison to match old or new NAR1 template, currently not that stable, consider changes to
            simply matching with higher roi here.
        :param img: opencv image, the first page of the input document
        :return: whether the input document is of old or new NAR1 format
        ;:raises
        """

        old_template = cv2.imread(OLD_TEMPLATE_PATH + 'NAR1-0.png')
        new_template = cv2.imread(NEW_TEMPLATE_PATH + 'NAR1-0.png')
        web_template = cv2.imread(WEB_TEMPLATE_PATH + 'NAR1-0.png')

        # check if web form, then check whether this is old or new NAR1
        doctype = match_template_hist(img, [new_template, old_template, web_template])

        if doctype == 0:
            path = NEW_TEMPLATE_PATH
        elif doctype == 1:
            path = OLD_TEMPLATE_PATH
        elif doctype == 2:
            path = WEB_TEMPLATE_PATH
        else:
            path = NEW_TEMPLATE_PATH

        templates = self.__load_roi(path)
        return path, templates

    def __load_roi(self, path):
        """
            loads and return the specified template from file
        :param path: the path to the template folder, for NAR1, please follow the naming scheme in ROI_template
        :return: the list of dictionaries with ROI info for each page of the document, currently the dicts are in the
        format: {'field name': array([x,y,w,h])}
        """
        loc_regex = r'{"name":"rect","x":(\d+),"y":(\d+),"width":(\d+),"height":(\d+)}'
        name_regex = r'{"Label":"([\s\S]+)"}'
        pg_regex = r'NAR1-(\S+).png'

        template = {'page': [], 'Labels': [], 'Coords': []}

        # loads predefined (via format)template csv files
        ROI = pd.read_csv(path + 'NAR1.csv')

        # use regex to match roi info from via format csv files
        for entry in ROI['region_shape_attributes'].values:
            entry_match = re.match(loc_regex, entry)
            if entry_match is not None:
                template['Coords'].append(np.array(list(map(int, entry_match.groups()))))
            else:
                template['Coords'].append(None)

        for entry in ROI['region_attributes'].values:
            entry_match = re.match(name_regex, entry)
            if entry_match is not None:
                template['Labels'].append(entry_match.group(1))
            else:
                template['Labels'].append(None)

        for entry in ROI['filename'].values:
            entry_match = re.match(pg_regex, entry)
            template['page'].append(entry_match.group(1))

        # group the results into dictionaries
        template = pd.DataFrame.from_dict(template)

        template_0 = template.loc[template['page'] == '0'].drop(columns='page')
        template_0 = dict(zip(template_0['Labels'].values, template_0['Coords'].values))

        template_1 = template.loc[template['page'] == '1'].drop(columns='page')
        template_1 = dict(zip(template_1['Labels'].values, template_1['Coords'].values))

        template_3 = template.loc[template['page'] == '3'].drop(columns='page')
        template_3 = dict(zip(template_3['Labels'].values, template_3['Coords'].values))

        template_s1 = template.loc[template['page'] == 's1'].drop(columns='page')
        template_s1 = dict(zip(template_s1['Labels'].values, template_s1['Coords'].values))

        template_cb = template.loc[template['page'] == 'cb'].drop(columns='page')
        template_cb = dict(zip(template_cb['Labels'].values, template_cb['Coords'].values))

        return [template_0, template_1, template_3, template_s1, template_cb]
