import cv2
import numpy as np
from NAR1.ImgProc import exp_box_extraction
from NAR1.RecConfig import BOX_MIN_AREA, BOX_V_KERNEL_RATIO, BOX_H_KERNEL_RATIO
from NAR1.AlignTransform import get_bboxes_description, match_bboxes, get_match_similarity

def match_template_hist(src_img, templates):
    """
        matches src to one of the images in templates
    :param src: opencv image object, the source image that we want to classify
    :param templates: a list of opencv image objects, the templates that we want to match
    :return: the index of the image in templates that has the highest similarity score with src
             returns None if no satisfiable match is found in the given templates
    """
    # TODO: it would be good if we can definitely return a result

    src = cv2.cvtColor(np.asarray(src_img), cv2.COLOR_BGR2GRAY)
    img_h, img_w = src.shape
    src_boxes = exp_box_extraction(src, BOX_MIN_AREA, BOX_V_KERNEL_RATIO, BOX_H_KERNEL_RATIO)
    dest_src = get_bboxes_description(src_boxes, src.shape[1], src.shape[0])

    scores = []
    for i, dst_img in enumerate(templates):
        dst = cv2.cvtColor(np.asarray(dst_img), cv2.COLOR_BGR2GRAY)
        dst_boxes = exp_box_extraction(dst, BOX_MIN_AREA, BOX_V_KERNEL_RATIO, BOX_H_KERNEL_RATIO)
        dest_dst = get_bboxes_description(dst_boxes, dst.shape[1], dst.shape[0])
        match_ind = match_bboxes(dest_src, dest_dst)
        score = get_match_similarity(src_boxes, dst_boxes, match_ind, img_w, img_h)
        scores.append(score)
    scores = np.asarray(scores)
    ind_match = np.argmin(scores)
    return ind_match
