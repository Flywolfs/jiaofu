"""
    performs page level functions, crops roi from respective images and feed to ItemRecognition
aggregates results and returns back to NAR1 class
"""
import cv2
import numpy as np
import pandas as pd
from PIL import Image
from collections import OrderedDict

from NAR1.ImgProc import exp_extract_grid, exp_box_extraction, intersection_over_union
from NAR1.MatchTemplate import match_template_hist
from NAR1.ItemRecognition import Item
from NAR1.PostProcess import parse_share, parse_director
from NAR1.RecConfig import BOX_MIN_AREA, BOX_V_KERNEL_RATIO, BOX_H_KERNEL_RATIO, GRID_V_KERNEL_RATIO, \
    GRID_H_KERNEL_RATIO, EN_TESS_CONFIG_PATH, CN_TESS_CONFIG_PATH
from NAR1.GridRegistration import grid_align


def draw(img, template, save_path):
    img_draw = img.copy()
    for k, v in template.items():
        if k is None or v is None:
            continue
        cv2.putText(img_draw, k, (v[0], v[1]), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 0), 2)
        cv2.rectangle(img_draw, (v[0], v[1]), (v[0]+v[2], v[1]+v[3]), (0,0,255), 2)
    cv2.imwrite(save_path, img_draw)


def rec_document(pages, templates, path, lang):
    """
        recognize the given documents according to the given template
    :param pages: list of opencv image objects, list of input document images
    :param templates: list of dictionaries, each of which contains the roi information on a single page
    :param path: String, path of the template images
    :param lang: char, 'C' or 'E' character indicating the language of the document, specific to NAR1
    :param web: bool, True if the document is web form
    :return: pandas DataFrame, the recognition results for this NAR01 document
    """
    # TODO: convert to return DataFrame later, this can be done by changing the Page class
    # TODO: this can be more general if we specify page number in template
    #       (and include blank templates for pages that does not have roi)
    # TODO: page 6 is now deprecated, hookup page template matching asap!
    [template_0, template_1, template_3, template_s1, template_cb] = templates

    # currently only these two are needed
    img_0 = cv2.imread(path+'NAR1-0.png')
    img_1 = cv2.imread(path+'NAR1-1.png')
    img_3 = cv2.imread(path+'NAR1-3.png')
    img_s1 = cv2.imread(path+'NAR1-s1.png')
    img_cb = cv2.imread(path+'NAR1-cb.png')

    img_appendices = [img_s1, img_cb]

    draw(img_0, template_0, "draw/NAR1-0.png")
    draw(img_1, template_1, "draw/NAR1-1.png")
    draw(img_3, template_3, "draw/NAR1-3.png")
    draw(img_s1, template_s1, "draw/NAR1-s1.png")
    draw(img_cb, template_cb, "draw/NAR1-cb.png")

    # sets a counter for the current number of directors
    # TODO: find a better way to implement this (separate the number of director from entire document's recognition
    #       result)
    curr_director = 1

    # Recognizes main form and aggregates results
    text_pages = []
    page_0 = Page(img=pages[0], img_template=img_0, rois=template_0, lang=lang)
    text_pages.append(page_0.recognize())

    page_1 = Page(img=pages[1], img_template=img_1, rois=template_1, lang=lang)
    text_pages.append(page_1.recognize())

    page_3 = Page(img=pages[3], img_template=img_3, rois=template_3, lang=lang)
    text_pages.append(parse_director(page_3.recognize(), curr_director))

    # do template matching from 7th page onward
    # TODO: set a director counter here to help post processing
    for page in pages[7:]:
        match = match_template_hist(page, img_appendices)
        if match == 0:
            page = Page(img=page, img_template=img_s1, rois=template_s1, lang=lang)
            text_pages.append(parse_share(page.recognize()))
        elif match == 1:
            page = Page(img=page, img_template=img_cb, rois=template_cb, lang=lang)
            curr_director += 1
            text_pages.append(parse_director(page.recognize(), curr_director))
        else:
            # happens when the appendices does not match schedule 1 or continuation sheet
            # theoretically, we do not have to handle anything after continuation sheet B, since the continuation sheets
            # have to be filled in alphabetical order and we are not interested in anything after B.
            # TODO: verify if above comment is true
            pass

    # merge the recognition results into a single DataFrame
    # result = pd.concat(text_pages)
    result = OrderedDict()
    for pg in text_pages:
        for k,v in pg.items():
            if k in result.keys():
                result[k] += v
            else:
                result[k] = v
    return result


class Page:
    def __init__(self, img, img_template, rois, lang):
        """
            Init the page object
        :param img: cv2 image, The image of the respective page
        :param img_template: cv2 image, The template image of the respective page
        :param rois: dict, the template containing the roi information {'fieldname': (x,y,w,h)}
        :param lang: char, 'C' means input is a chinese document, 'E' indicates an English one
        """
        self._img = img
        self._rois = rois
        self._img_template = img_template
        self.lang = lang
        self.page_settings = self._load_page_ocr_settings()
        # initialized for inter-object communication
        self.v_borders = None
        # TODO: hkid could be handled at post-processing
        # self.hkid = None

    def _load_page_ocr_settings(self):
        """
            loads tesseract recognition setting for items on this particular page
        :return:
        """
        if self.lang == 'E':
            path = EN_TESS_CONFIG_PATH
        else:
            path = CN_TESS_CONFIG_PATH

        page_settings = pd.read_csv(path, index_col='LABEL')
        return page_settings

    def recognize(self):
        """
            recognizes all specified rois on a given page
        :return: pandas Dataframe, the recognized key, value pairs
        """
        pg = cv2.cvtColor(np.asarray(self._img), cv2.COLOR_BGR2GRAY)

        template = cv2.cvtColor(self._img_template, cv2.COLOR_BGR2GRAY)

        # aligns the images
        pg = grid_align(pg, template, BOX_MIN_AREA, GRID_V_KERNEL_RATIO, GRID_H_KERNEL_RATIO)
        grid = exp_extract_grid(pg, BOX_MIN_AREA, GRID_V_KERNEL_RATIO, GRID_H_KERNEL_RATIO)
        boxes = exp_box_extraction(pg, BOX_MIN_AREA, BOX_V_KERNEL_RATIO, BOX_H_KERNEL_RATIO)

        # inversely binarize and remove gridlines from the document
        _, pg = cv2.threshold(pg, 128, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
        _, grid = cv2.threshold(grid, 128, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
        pg = cv2.subtract(pg, grid)

        # cv2.namedWindow("a", cv2.WINDOW_NORMAL)
        # cv2.imshow("a", pg)
        # cv2.waitKey()

        pg_text = OrderedDict()
        for key, coords in self._rois.items():
            if len(boxes) != 0:
                iou = [intersection_over_union(detected=box, template=coords) for box in boxes]
                ind = np.argmax(iou)
                # if IOU is too low or cannot get correct subimg, use template coordinates instead
                if iou[ind] > 0.2:
                    val = boxes[ind]
                else:
                    val = coords
            else:
                val = coords

            subimg = pg[val[1]:val[1] + val[3], val[0]:val[0] + val[2]]

            # cv2.imshow("b", subimg)
            # cv2.waitKey()

            # convert to PIL image format for convenience in ItemRecognition
            subimg = Image.fromarray(subimg)
            item = Item(key, subimg, self)

            # assigns to corresponding key in dict
            pg_text[key] = item.rec_img()

        # convert to DataFrame
        # pg_text = pd.DataFrame(pg_text.items(), columns=['Label', 'Value'])
        return pg_text
