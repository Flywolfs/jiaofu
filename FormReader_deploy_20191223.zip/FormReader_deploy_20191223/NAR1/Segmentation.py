"""
    Handles segmentation tasks
"""
# TODO: make it possible for user to specify text direction
# TODO: In order to preserve text block structure, currently need to convert to CV2 format as a hot-fix,
#       Switch to full PIL implementation later

import cv2
import numpy as np


def seg_doc(img, para_open_kernel_size, line_open_kernel_size, lower_pw_limit, lower_lw_limit):
    """
        segments multiple blocks of texts into lines
    :param img:
    :param para_open_kernel_size:
    :param line_open_kernel_size:
    :param lower_pw_limit:
    :param lower_lw_limit:
    :return: result, list, where each element is a list of bounding box coordinates (x,y,w,h) for lines in one
    corresponding block
    """
    img = np.asarray(img)
    # cv2.imshow("b", np.asarray(img))
    # cv2.waitKey()
    blks, v_borders = _morph_seg_to_para(img, para_open_kernel_size, lower_pw_limit)
    result = []
    for blk in blks:
        x, y, w, h = blk
        blk_img = img[y:y+h, x:x+w]
        lines = _moprh_seg_to_line(blk_img, line_open_kernel_size, lower_lw_limit)

        blk_lines = []
        # parse to coordinate on original image
        for i, line in enumerate(lines):
            (x0, y0, w0, h0) = line
            line = (x+x0, y+y0, w0, h0)
            blk_lines.append(line)
        result.append(blk_lines)

    return result, v_borders


def seg_para(img, line_open_kernel_size, lower_lw_limit):
    """
        segments multiple blocks of texts into lines
    :param img:
    :param line_open_kernel_size:
    :param lower_lw_limit:
    :return: list of bounding box coordinates (x,y,w,h) for the
    """
    img = np.asarray(img)
    # cv2.imshow("b", np.asarray(img))
    # cv2.waitKey()
    lines = _moprh_seg_to_line(img, line_open_kernel_size, lower_lw_limit)
    '''
    # parse to coordinate on original image
    for i, line in enumerate(lines):
        (x0, y0, w0, h0) = line
        lines[i] = (x+x0, y+y0, w0, h0)
        result.append(lines)
    '''
    return lines


def seg_word(img, dilate_kernel_size, lower_cw_limit):
    """
        segments a single word into characters
    :param img:
    :param dilate_kernel_size:
    :param lower_cw_limit:
    :return: list of bounding box coordinates (x,y,w,h) for the
    """
    img = np.asarray(img)
    chars = _morph_seg_to_char(img, dilate_kernel_size, lower_cw_limit)
    return chars


def trim_line(img, line_open_kernel_size, lower_lw_limit):
    """
        trims image of a single text line, identical to calling seg_para...
        Useful when text is not centered in ROI
    :param img:
    :param line_open_kernel_size:
    :param lower_lw_limit:
    :return: bounding box coordinates (x,y,w,h)
    """
    img = np.asarray(img)
    lines = _moprh_seg_to_line(img, line_open_kernel_size, lower_lw_limit)
    return lines


def _morph_seg_to_para(img, open_kernel_size, lower_pw_limit):
    """
        segments paragraph/ text blocks in image using morphological transformations, assumes paragraphs are ordered
        vertically

    :param img: numpy 2d array, the GRAYSCALE image from which the function segments the paragraph
    :param open_kernel_size: int, the size of the kernel used for open transformations, larger value results in harsher
        denoising.
    :param lower_pw_limit: int, the smallest paragraph width allowed
    :return: A list of sgemented paragraph sub-images and their corresponding upper and lower vertical coordinates
    """

    # img = pad_img(img, color=(0, 0, 0))

    open_kernel = np.ones((open_kernel_size, open_kernel_size), np.uint8)
    open_img = cv2.morphologyEx(img, cv2.MORPH_OPEN, open_kernel)

    dilate_kernel = np.ones((50, 100), np.uint8)
    img_dilation = cv2.dilate(open_img, dilate_kernel, iterations=1)

    im2, ctrs, hier = cv2.findContours(img_dilation.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # sort contours by ascending y direction
    sorted_ctrs = sorted(ctrs, key=lambda item: cv2.boundingRect(item)[1])

    blks = []
    vertical_borders = []
    for i, ctr in enumerate(sorted_ctrs):
        # Get bounding box
        x, y, w, h = cv2.boundingRect(ctr)

        # Getting ROI
        if h > lower_pw_limit:
            # blk = img[y:y + h, x:x + w]
            # blks.append(blk)
            blks.append((x, y, w, h))
            vertical_borders.append((y, y + h))

    # blks.reverse()
    # vertical_borders.reverse()
    return blks, vertical_borders


def _moprh_seg_to_line(img, open_kernel_size, lower_lw_limit):
    """
        segments text lines in image using morphological transformations. Actually able to segment words as well.
        Assumes paragraphs are ordered vertically

    :param img: numpy 2d array, the GRAYSCALE image from which the function segments the lines
    :param open_kernel_size: int, the size of the kernel used for open transformations, larger value results in harsher
        denoising.
    :param lower_lw_limit:int, the smallest linewidth allowed
    :return: A list of sgemented line subimages

    """
    open_kernel = np.ones((open_kernel_size, open_kernel_size), np.uint8)
    open_img = cv2.morphologyEx(img, cv2.MORPH_OPEN, open_kernel)

    # dilate horizontally
    dilate_kernel = np.ones((7, 100), np.uint8)
    img_dilation = cv2.dilate(open_img, dilate_kernel, iterations=1)

    im2, ctrs, hier = cv2.findContours(img_dilation.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # sort contours by ascending y direction
    sorted_ctrs = sorted(ctrs, key=lambda item: cv2.boundingRect(item)[1])
    # sorted_ctrs = ctrs.sort(key = lambda x:cv2.boundingRect(x)[1])

    lines = []
    for i, ctr in enumerate(sorted_ctrs):
        # Get bounding box
        x, y, w, h = cv2.boundingRect(ctr)

        # Getting ROI
        if h > lower_lw_limit:
            # line = img[y:y + h, x:x + w]
            # lines.append(line)
            lines.append((x, y, w, h))

    return lines


def _morph_seg_to_char(img, dilate_kernel_size, lower_cw_limit):
    """
        segments characters in image using morphological transformations, assumes characters are ordered horizontally

    :param img: numpy 2d array, the GRAYSCALE image from which the function segments the characters
    :param dilate_kernel_size: int, The size of the kernel used to dilate the image
    :param lower_cw_limit: int, the smallest character width allowed
    :return: A list of sgemented character subimages
    """

    # enlarge the image to get easier segmentation
    # im = cv2.resize(word_img, None, fx=4, fy=4, interpolation=cv2.INTER_CUBIC)

    # dilate the image to get character blobs
    dilate_kernel = np.ones((dilate_kernel_size, dilate_kernel_size), np.uint8)
    img_dilation = cv2.dilate(img, dilate_kernel, iterations=1)

    im2, ctrs, hier = cv2.findContours(img_dilation.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # sort contours by upper left points
    sorted_ctrs = sorted(ctrs, key=lambda ctr: cv2.boundingRect(ctr)[0])

    chars = []
    for i, ctr in enumerate(sorted_ctrs):
        # Get bounding box
        x, y, w, h = cv2.boundingRect(ctr)

        # Getting ROI
        if w > lower_cw_limit:
            # char = img[y:y + h, x:x + w]
            # chars.append(char)
            chars.append((x, y, w, h))
    return chars


'''
def seg_lines_proj(img, LOWER_LW_LIMIT=10, LINE_DETECT_THRES=1):
    """
        segments text lines in image using histogram back projection

    :param img: numpy 2d array, the GRAYSCALE image from which the function segments the lines
    :param LOWER_LW_LIMIT: int, the smallest linewidth allowed
    :param LINE_DETECT_THRES: int, the threshold over which a pixel would be considered another line
    :return: A list of sgemented line subimages
    """

    hist = cv2.reduce(img, 1, cv2.REDUCE_AVG).reshape(-1)

    th = LINE_DETECT_THRES
    H, W = img.shape[:2]
    uppers = [y for y in range(H - 1) if hist[y] <= th and hist[y + 1] > th]
    lowers = [y for y in range(H - 1) if hist[y] > th and hist[y + 1] <= th]

    # add the uppermost and lower most lines to the detected borders
    uppers.insert(0, 0)
    lowers.append(H)

    lines = []
    for (upper, lower) in zip(uppers, lowers):
        line = img[upper:lower, :]
        if line.shape[0] > LOWER_LW_LIMIT:
            lines.append(line)

    return lines
'''


'''
def seg_words_morph(img, OPEN_KERNEL_SIZE=3, lower_cw_limit=LOWER_CW_LIMIT):
    """
    segments words in image using morphological transformations, currently most suitable to

    Args:
        img: numpy 2d array, the graysacle image to be altered
        OPEN_KERNEL_SIZE: int, the size of the kernel used for open transformations,
                        larger value results in harsher denoising.
        LOWER_LW_LIMIT: int, the smallest linewidth allowed

    Returns:
        A list of sgemented line subimages
    """

    open_kernel = np.ones((OPEN_KERNEL_SIZE, OPEN_KERNEL_SIZE), np.uint8)
    open_img = cv2.morphologyEx(img, cv2.MORPH_OPEN, open_kernel)

    dilate_kernel = np.ones((1, 100), np.uint8)
    dilate_img = cv2.dilate(open_img, dilate_kernel, iterations=1)

    im2, ctrs, hier = cv2.findContours(dilate_img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # sort contours by ascending x direction
    sorted_ctrs = sorted(ctrs, key=lambda ctr: cv2.boundingRect(ctr)[0])

    words = []
    for i, ctr in enumerate(sorted_ctrs):
        # Get bounding box
        x, y, w, h = cv2.boundingRect(ctr)

        # Getting ROI, cropping only horizontal sections
        if h > LOWER_LW_LIMIT and w > lower_cw_limit:
            word = img[:, x:x + w]

            words.append(word)

    words.reverse()
    return words
'''


'''
def _morph_seg_to_char(word_img, DILATE_KERNEL_SIZE=5, LOWER_CW_LIMIT=20):
    """
    segments characters in image using histogram back projections

    Args:
        word_img: numpy 2d array, the graysacle image to be altered
        LOWER_CW_LIMIT: int, the smallest char width allowed
        DILATE_KERNEL_SIZE: int, the threshold, over which a pixel would be considerd
                            another line, a bit wonky actually...
    Returns:
        A list of sgemented character subimages
    """
    # enlarge the image to get easier segmentation (?)
    # open_kernel = np.ones((5,5),np.uint8)
    # im = cv2.morphologyEx(word_img, cv2.MORPH_OPEN, open_kernel)
    # im = cv2.resize(word_img,None,fx=4, fy=4, interpolation = cv2.INTER_CUBIC)
    # im = word_img
    # dilate vertically ?
    dilate_kernel = np.ones((100, 1), np.uint8)
    img_dilation = cv2.dilate(word_img, dilate_kernel, iterations=1)

    im2, ctrs, hier = cv2.findContours(img_dilation.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # sort contours by ascending x direction
    sorted_ctrs = sorted(ctrs, key=lambda ctr: cv2.boundingRect(ctr)[0])

    chars = []
    for i, ctr in enumerate(sorted_ctrs):
        # Get bounding box
        x, y, w, h = cv2.boundingRect(ctr)

        # Getting ROI
        if w > LOWER_CW_LIMIT:
            char = im[y:y + h, x:x + w]
            # char = cv2.resize(char,None,fx=0.25, fy=0.25, interpolation = cv2.INTER_CUBIC)
            chars.append(char)

    return chars, img_dilation
'''

