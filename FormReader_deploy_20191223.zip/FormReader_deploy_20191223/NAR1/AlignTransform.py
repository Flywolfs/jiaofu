import cv2
import numpy as np
import itertools

from NAR1.RecConfig import BOX_MIN_AREA, BOX_V_KERNEL_RATIO, BOX_H_KERNEL_RATIO
from NAR1.ImgProc import exp_box_extraction


def get_bboxes_description(bboxes, img_w, img_h):
    dest = []
    for bbox in bboxes:
        x, y, w, h = bbox
        xc = x + 0.5 * w
        yc = y + 0.5 * h
        dest.append([xc / img_w, yc / img_h, w / img_w, h / img_h])
    return np.asarray(dest)

def match_bboxes(dest_src, dest_dst):
    m = dest_src.shape[0]
    n = dest_dst.shape[0]
    scores = np.zeros((m, n))
    for i in range(m):
        for j in range(n):
            scores[i][j] = np.sum(np.abs(dest_src[i] - dest_dst[j]))

    scores_min_src = np.argmin(scores, 1)
    scores_min_dst = np.argmin(scores, 0)

    match_ind = []
    for i in range(scores_min_src.shape[0]):
        j = scores_min_src[i]
        if i == scores_min_dst[j]:
            match_ind.append((i, j))

    return match_ind

def box_vertices(box):
    vertices = []
    vertices.append((box[0], box[1]))
    vertices.append((box[0] + box[2], box[1]))
    vertices.append((box[0] + box[2], box[1] + box[3]))
    vertices.append((box[0], box[1] + box[3]))
    return vertices

def get_perspective_transform(src_boxes, dst_boxes, match_ind):
    src_pts = []
    dst_pts = []
    for i, j in match_ind:
        src_box = src_boxes[i]
        dst_box = dst_boxes[j]
        src_pts += box_vertices(src_box)
        dst_pts += box_vertices(dst_box)

    src_pts = np.asarray(src_pts)
    dst_pts = np.asarray(dst_pts)
    M, _ = cv2.findHomography(src_pts, dst_pts, cv2.LMEDS)
    return M


def get_match_similarity(src_boxes, dst_boxes, match_ind, img_w, img_h):
    src_pts = []
    dst_pts = []
    for i, j in match_ind:
        src_box = src_boxes[i]
        dst_box = dst_boxes[j]
        src_pts += box_vertices(src_box)
        dst_pts += box_vertices(dst_box)

    src_pts = np.asarray(src_pts)
    dst_pts = np.asarray(dst_pts)
    M, _ = cv2.findHomography(dst_pts, src_pts, cv2.LMEDS)
    if M is None:
        return 1e5

    n = dst_pts.shape[0]
    dst_pts_ = np.concatenate((dst_pts, np.ones((n, 1))), 1)
    warped_src_pts = dst_pts_.dot(M)[:,:2]

    score = ((warped_src_pts - src_pts) / np.asarray([img_w, img_h])) ** 2
    score = np.mean(np.sqrt(np.sum(score, 1))) - 0.0025 * len(match_ind)
    return score


def align_img_mat(src, dst):
    '''
    Aligns a source image to its destination image, wrapper for the Align class

    Args:
        src: The source image
        dst: The destination image

    Returns:
        The aligned image

    Raises:
        Value Error. Occurs if the two images fail to align entirely
    '''
    img_h, img_w = src.shape
    src_boxes = exp_box_extraction(src, BOX_MIN_AREA, BOX_V_KERNEL_RATIO, BOX_H_KERNEL_RATIO)
    dst_boxes = exp_box_extraction(dst, BOX_MIN_AREA, BOX_V_KERNEL_RATIO, BOX_H_KERNEL_RATIO)

    dest_src = get_bboxes_description(src_boxes, src.shape[1], src.shape[0])
    dest_dst = get_bboxes_description(dst_boxes, dst.shape[1], dst.shape[0])

    scores = []

    offsets = list(itertools.product(
        np.arange(-0.12, 0.1201, 0.06),
        np.arange(-0.12, 0.1201, 0.06),
        np.arange(0.88, 1.1201, 0.04),
        np.arange(0.88, 1.1201, 0.04)
    ))

    for offset in offsets:
        dx, dy, dw, dh = offset
        dest_src_ = (dest_src + np.asarray((dx, dy, 0., 0.))) * np.asarray([dw, dh, dw, dh])
        match_ind = match_bboxes(dest_src_, dest_dst)
        score = get_match_similarity(src_boxes, dst_boxes, match_ind, img_w, img_h)
        scores.append(score)

    dx, dy, dw, dh = offsets[np.argmin(scores)]
    dest_src_ = (dest_src + np.asarray((dx, dy, 0., 0.))) * np.asarray([dw, dh, dw, dh])
    match_ind = match_bboxes(dest_src_, dest_dst)
    M = get_perspective_transform(src_boxes, dst_boxes, match_ind)

    # src_show = cv2.cvtColor(src, cv2.COLOR_GRAY2BGR)
    # dst_show = cv2.cvtColor(dst, cv2.COLOR_GRAY2BGR)
    #
    # for src_box in src_boxes:
    #     cv2.rectangle(src_show, (src_box[0], src_box[1]), (src_box[0] + src_box[2], src_box[1] + src_box[3]),
    #                   color=(0, 0, 255), thickness=2)
    #
    # for dst_box in dst_boxes:
    #     cv2.rectangle(dst_show, (dst_box[0], dst_box[1]), (dst_box[0] + dst_box[2], dst_box[1] + dst_box[3]),
    #                   color=(0, 0, 255), thickness=2)
    #
    # for i, j in match_ind:
    #     c = (np.random.randint(127,255), np.random.randint(127,255), np.random.randint(127,255))
    #     src_box = src_boxes[i]
    #     dst_box = dst_boxes[j]
    #     cv2.rectangle(src_show, (src_box[0], src_box[1]), (src_box[0] + src_box[2], src_box[1] + src_box[3]),
    #                   color=c, thickness=5)
    #     cv2.rectangle(dst_show, (dst_box[0], dst_box[1]), (dst_box[0] + dst_box[2], dst_box[1] + dst_box[3]),
    #                   color=c, thickness=5)
    #
    # cv2.namedWindow("src_show", cv2.WINDOW_NORMAL)
    # cv2.imshow("src_show", src_show)
    # cv2.namedWindow("dst_show", cv2.WINDOW_NORMAL)
    # cv2.imshow("dst_show", dst_show)
    # cv2.waitKey()

    return M


# def sift_extraction(img):
#     # Extract key points and SIFT descriptors
#     sift = cv2.xfeatures2d.SIFT_create()
#     kp, desc = sift.detectAndCompute(img, None)
#
#     # Extract positions of key points
#     kp = np.array([p.pt for p in kp]).T
#
#     return kp, desc
#
#
# def match_sift(desc_src, desc_dst):
#     """
#
#     :param desc_src:
#     :param desc_dst:
#     :return:
#     """
#     # TODO: change to FLANN-based matcher later
#     # Match descriptor and obtain two best matches
#     bf = cv2.BFMatcher()
#     matches = bf.knnMatch(desc_src, desc_dst, k=2)
#
#     # Initialize output variable
#     fit_pos = np.array([], dtype=np.int32).reshape((0, 2))
#
#     matches_num = len(matches)
#     for i in range(matches_num):
#         # Obtain the good match if the ration id smaller than 0.8
#         if matches[i][0].distance <= LOWE_RATIO * matches[i][1].distance:
#             temp = np.array([matches[i][0].queryIdx,
#                              matches[i][0].trainIdx])
#             # Put points index of good match
#             fit_pos = np.vstack((fit_pos, temp))
#
#     return fit_pos
#
#
# def estimate_affine(pts_s, pts_t):
#     """
#
#     :param pts_s:
#     :param pts_t:
#     :return:
#     """
#     # Get the number of corresponding points
#     pts_num = pts_s.shape[1]
#
#     # Initialize the matrix M,
#     # M has 6 columns, since the affine transformation
#     # has 6 parameters in this case
#     M = np.zeros((2 * pts_num, 6))
#
#     for i in range(pts_num):
#         # Form the matrix m
#         temp = [[pts_s[0, i], pts_s[1, i], 0, 0, 1, 0],
#                 [0, 0, pts_s[0, i], pts_s[1, i], 0, 1]]
#         M[2 * i: 2 * i + 2, :] = np.array(temp)
#
#     # Form the matrix b,
#     # b contains all known target points
#     b = pts_t.T.reshape((2 * pts_num, 1))
#
#     try:
#         # Solve the linear equation
#         theta = np.linalg.lstsq(M, b)[0]
#
#         # Form the affine transformation
#         A = theta[:4].reshape((2, 2))
#         t = theta[4:]
#     except np.linalg.linalg.LinAlgError:
#         # If M is singular matrix, return None
#         # print("Singular matrix.")
#         A = None
#         t = None
#
#     return A, t
#
#
# def find_affine_transform(kp_src, kp_dst, fit_pos, k=3, threshold=1):
#     """
#
#     :param kp_src:
#     :param kp_dst:
#     :param fit_pos:
#     :param k: the number of corresponding points
#     :param threshold: a threshold determins which points are outliers in the RANSAC process, if the residual is larger
#                     than threshold, it can be regarded as outliers
#     :return:
#     """
#     # Extract corresponding points from all key points
#     kp_src = kp_src[:, fit_pos[:, 0]]
#     kp_dst = kp_dst[:, fit_pos[:, 1]]
#
#     # Apply RANSAC to find most inliers
#     _, _, inliers = ransac_fit(kp_src, kp_dst)
#
#     # Extract all inliers from all key points
#     kp_src = kp_src[:, inliers[0]]
#     kp_dst = kp_dst[:, inliers[0]]
#
#     # Use all inliers to estimate transform matrix
#     A, t = estimate_affine(kp_src, kp_dst)
#     M = np.hstack((A, t))
#
#     return M
#
#
# def residual_lengths(A, t, pts_s, pts_t):
#     if not(A is None) and not(t is None):
#         # Calculate estimated points:
#         # pts_esti = A * pts_s + t
#         pts_e = np.dot(A, pts_s) + t
#
#         # Calculate the residual length between estimated points
#         # and target points
#         diff_square = np.power(pts_e - pts_t, 2)
#         residual = np.sqrt(np.sum(diff_square, axis=0))
#     else:
#         residual = None
#
#     return residual
#
#
# def ransac_fit(pts_s, pts_t,  K=3, threshold=1):
#
#     # Initialize the number of inliers
#     inliers_num = 0
#
#     # Initialize the affine transformation A and t,
#     # and a vector that stores indices of inliers
#     A = None
#     t = None
#     inliers = None
#
#     for i in range(RANSAC_ITER_NUM):
#         # Randomly generate indices of points correspondences
#         idx = np.random.randint(0, pts_s.shape[1], (K, 1))
#         # Estimate affine transformation by these points
#         A_tmp, t_tmp = estimate_affine(pts_s[:, idx], pts_t[:, idx])
#
#         # Calculate the residual by applying estimated transformation
#         residual = residual_lengths(A_tmp, t_tmp, pts_s, pts_t)
#
#         if not(residual is None):
#             # Obtain the indices of inliers
#             inliers_tmp = np.where(residual < threshold)
#             # Obtain the number of inliers
#             inliers_num_tmp = len(inliers_tmp[0])
#
#             # Set affine transformation and indices og inliers
#             # in one iteration which has the most of inliers
#             if inliers_num_tmp > inliers_num:
#                 # Update the number of inliers
#                 inliers_num = inliers_num_tmp
#                 # Set returned value
#                 inliers = inliers_tmp
#                 A = A_tmp
#                 t = t_tmp
#         else:
#             pass
#
#     return A, t, inliers
#
#
# def rev_homo_orb(src, dst, MAX_FEATURES, LOWE_RATIO):
#     orb = cv2.ORB_create(MAX_FEATURES)
#     # find the keypoints and descriptors with SIFT
#     # store keypoints and descriptors of template for speed
#     keypoints_obj, descriptors_obj = orb.detectAndCompute(dst, None)
#     keypoints_scene, descriptors_scene = orb.detectAndCompute(src, None)
#
#     matcher = cv2.BFMatcher()
#     matches = matcher.knnMatch(descriptors_obj, descriptors_scene, 2)
#
#     matchesMask = [[0, 0] for i in range(len(matches))]
#     good_matches = []
#
#     # ratio test as per Lowe's paper, this is too slow!!!
#     for i, (m, n) in enumerate(matches):
#         if m.distance < 0.7 * n.distance:
#             matchesMask[i] = [1, 0]
#             good_matches.append(m)
#
#     obj = np.empty((len(good_matches), 2), dtype=np.float32)
#     scene = np.empty((len(good_matches), 2), dtype=np.float32)
#
#     for i in range(len(good_matches)):
#         obj[i, 0] = keypoints_obj[good_matches[i].queryIdx].pt[0]
#         obj[i, 1] = keypoints_obj[good_matches[i].queryIdx].pt[1]
#         scene[i, 0] = keypoints_scene[good_matches[i].trainIdx].pt[0]
#         scene[i, 1] = keypoints_scene[good_matches[i].trainIdx].pt[1]
#
#     try:
#         H, _ = cv2.findHomography(scene, obj, cv2.RANSAC)
#         aligned = cv2.warpPerspective(src=src, M=H, \
#                                       dsize=tuple(dst.shape[1::-1]))
#
#         return aligned
#
#     except cv2.error as e:
#         print('Not enough feature points, please adjust the maximum feature setting:', e)
#         return
#
#
