import cv2
import numpy as np
from PIL import Image
from tesserocr import PyTessBaseAPI, PSM

from NAR1.ImgProc import exp_extract_grid
from NAR1.AlignTransform import align_img_mat
from config import TESSDATA_PATH


def rotate_image(image, angle, border_value=(255, 255, 255)):
    """
            rotates an opencv image
    :param image:
    :param angle:
    :param border_value: The color of the border resulted from the rotation
    :return:
    """
    image_center = tuple(np.array(image.shape[1::-1]) / 2)
    rot_mat = cv2.getRotationMatrix2D(image_center, angle, 1.0)
    result = cv2.warpAffine(image, rot_mat, image.shape[1::-1], flags=cv2.INTER_LINEAR, borderValue=border_value)
    return result


def __rad_2_deg(rad):
    return rad * 180 /np.pi


def detect_angle(img):
    """
        returns the skewing angle in degrees of a given document
        (positive for clockwise)
    """
    with PyTessBaseAPI(path=TESSDATA_PATH, psm=PSM.AUTO_OSD) as api:
        image = Image.fromarray(img)
        api.SetImage(image)
        api.Recognize()

        it = api.AnalyseLayout()
        orientation, direction, order, deskew_angle = it.Orientation()
        deskew_angle = __rad_2_deg(deskew_angle)
    return deskew_angle


def deskew_img(img):
    deskew_angle = detect_angle(img)
    deskewed = rotate_image(img, deskew_angle)
    return deskewed


def grid_align(src, dst, min_area, v_kernel_ratio, h_kernel_ratio):
    """
        aligns the two given GRAYSCALE (NOT INVERSELY-BINARIZED)image by aligning their respective grids
    :param src:
    :param dst:
    :param min_area:
    :param v_kernel_ratio:
    :param h_kernel_ratio:
    :return:
    """
    # deskews image first to prevent
    src = deskew_img(src)

    # find and perform linear transformation
    M = align_img_mat(src=src, dst=dst)
    H, W = dst.shape
    assert len(M.shape) == 2
    if M.shape[1] == 2:
        warped = cv2.warpAffine(src, M, (W, H))
    elif M.shape[1] == 3:
        warped = cv2.warpPerspective(src, M, (W, H))
    return warped
