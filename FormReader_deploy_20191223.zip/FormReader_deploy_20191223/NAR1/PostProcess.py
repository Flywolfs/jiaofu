"""
Post Processing functionalities: separating entries (e.g. share_addr to multiple share holders), calculating hkids
                                 completeness check (if critical info missing)
                                 TODO: add spell checking functions
"""
from collections import OrderedDict


def parse_share(result):
    """
        separate the list-formatted result into individual entries for shareholder informations
    :param result: pandas DataFrame, the recognition result for schedule 1 form
    :return: the parsed result in DataFrame
    """
    return result


def parse_director(result, curr_director):
    """

    :param result:
    :param curr_director:
    :return:
    """
    new_result = OrderedDict()
    hkid = []
    for k, v in result.items():
        if 'hkid' in k:
            hkid += v
        else:
            new_result[k.replace('director', 'director_{}'.format(curr_director))] = v
    hkid = ''.join(hkid)
    if len(hkid) >= 7:
        hkid += _calc_hkid_par(hkid)
    new_result['director_{}_hkid'.format(curr_director)] = [hkid]
    return new_result


def filter_non_ascii_chars(text):
    text = ''.join([ch for ch in text if ord(ch) < 128 and (ch.isalnum() or ch in " .,")]).strip()
    return text


def _calc_hkid_par(hkid):
    """
        calculates the character in parenthesis given the first 7 characters of a hkid

    :param hkid: The string of recognized HKID
    :return: The calculated last character of HKID
    """

    # convert the first characters to base 36 number
    if not hkid[0].isalpha():
        return ""
    for i in range(1, len(hkid)):
        if not hkid[i].isdigit():
            return ""
    pos_1 = int(hkid[0], 36)

    hkid_sum = 522 + pos_1 * 8 + \
               int(hkid[1]) * 7 + int(hkid[2]) * 6 + int(hkid[3]) * 5 + \
               int(hkid[4]) * 4 + int(hkid[5]) * 3 + int(hkid[6]) * 2

    # converts to base 11
    rmd = hkid_sum % 11
    result = 11 - rmd

    # Base 11 remainder match: 0,A,9,8,7,6,5,4,3,2,1
    if result == 11:
        result = '0'
    elif result == 10:
        result = 'A'
    else:
        result = str(result)

    return result
