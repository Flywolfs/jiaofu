"""
    handles item level recognition for NAR1 document
"""
# TODO: the current schemes of differentiating rois through string matching their keys is stupid
#       there should be a better way to handle this!
# TODO: currently using class based implementation (i.e. one object per item) to pass in the language variable,
#       There might be performance overhead due to this, change to regular method-based if design is optimized.

from itertools import chain
from math import isnan

import numpy as np
import tesserocr
from tesserocr import PSM, OEM, PyTessBaseAPI

from NAR1.ImgProc import resize_pil
from NAR1.RecConfig import PARA_OPEN_KERNEL_SIZE, LINE_OPEN_KERNEL_SIZE, LOWER_LW_LIMIT, LOWER_CW_LIMIT, \
    CHAR_DILATE_KERNEL_SIZE, LOWER_PW_LIMIT
from NAR1.Segmentation import seg_doc, seg_para, seg_word, trim_line
from config import TESSDATA_PATH
from NAR1.PostProcess import filter_non_ascii_chars
import cv2


def _img_to_text(img_list, args):
    """
        Where actual OCR happens, passes parameter in args to tesserocr.PytessAPI,
    :param img_list: list, possibly nested list of PIL Image objects, the images we wish to do OCR on
    :param args: dict, dictionary with parameter this item's OCR, has key:
                LABEL,SEG,LANG,WHITE_LIST,BLACK_LIST,RESIZE,PSM,OEM
    :return: a possibly nested list of strings, where the index of extracted text and its source image are identical
    """
    if not isinstance(img_list, list):
        img_list = [img_list]

    result = []
    # sets the language
    lang = args['LANG']

    # sets the OCR Engine Mode and Page Segmentation Mode
    curr_oem = OEM.TESSERACT_LSTM_COMBINED
    if 'word' in args['SEG']:
        curr_psm = PSM.SINGLE_WORD
    elif 'char' in args['SEG']:
        curr_psm = PSM.SINGLE_CHAR
        curr_oem = OEM.TESSERACT_ONLY
    else:
        curr_psm = PSM.SINGLE_LINE

    ret = tesserocr.get_languages(path=TESSDATA_PATH)

    # enumerates through the (possibly nested) list of PIL images, puts the OCR result to corresponding location in
    # test_list
    for ind, img in enumerate(img_list):
        # PyCharm import shenanigans
        with PyTessBaseAPI(lang=lang, path=TESSDATA_PATH, psm=curr_psm, oem=curr_oem) as api:
            if isinstance(args['WHITE_LIST'], str):
                api.SetVariable("tessedit_char_whitelist", args['WHITE_LIST'])
            if isinstance(args['BLACK_LIST'], str):
                api.SetVariable("tessedit_char_blacklist", args['BLACK_LIST'])

            api.SetImage(img)
            # assigns to the same index as the original image
            result.append(api.GetUTF8Text().strip())

    if len(result) > 1 and 'line' in args['SEG']:
        result.sort(key=lambda x: len(x), reverse=True)
        result = [result[0]]
    return result


def _nd_crop(img, coords):
    """
        crops images from the given coordinates
    :param img: PIL Image object, the source image to be cropped
    :param coords: list, coordinates in the (x,y,w,h) format
    :return: a list of subimage, with the same structure as that of coords
    """
    img_list = []
    for ind, val in enumerate(coords):
        x, y, w, h = val
        img_list.append(img.crop((x, y, x + w, y + h)))
    return img_list


class Item:

    def __init__(self, key, item_img, parent):
        # super(Item, self).__init__(self._img, self._img_template, self._rois, self.lang)
        self.key = key
        self.parent = parent
        self.ocr_settings, self.item_img = self._load_item_ocr_settings(item_img)

    def _load_item_ocr_settings(self, item_img):
        """
            loads ocr settings for the current item
        :param item_img: list, should be a list with only one opencv image object
        :return:
        """
        # LABEL,SEG,LANG,WHITE_LIST,BLACK_LIST,RESIZE,PSM,OEM
        item_settings = self.parent.page_settings.loc[self.key].to_dict()

        # do required rescaling if specified in setting
        if not isnan(item_settings['RESIZE']):
            item_img = resize_pil(item_img[0], item_settings['RESIZE'])
            # preserve the item_img's list structure
            item_img = [item_img]

        return item_settings, item_img

    def _get_item_text(self, segmode):
        """
            returns textual information of the given item
        :param segmode:
        :return:
        """
        if segmode == 'doc':
            coords, v_borders = seg_doc(self.item_img, PARA_OPEN_KERNEL_SIZE, LINE_OPEN_KERNEL_SIZE, LOWER_PW_LIMIT,
                                        LOWER_LW_LIMIT)
            result = []
            for i in range(len(coords)):
                img_list = _nd_crop(self.item_img, coords[i])
                # assigns to object variable
                result.append(_img_to_text(img_list, self.ocr_settings))
            # joins innermost item by newlines, gets a list of multiple paragraphs
            result = ['\n'.join(chain.from_iterable(*x)) for x in zip(result)]

        # single paragraph to multiple lines
        elif segmode == 'para':
            result = []
            w, h = self.item_img.size
            for border in self.parent.v_borders:
                blk = self.item_img.crop((0, border[0], w, border[1]))
                coords = seg_para(blk, LINE_OPEN_KERNEL_SIZE, LOWER_LW_LIMIT)
                img_list = _nd_crop(self.item_img, coords)
                result.append(_img_to_text(img_list, self.ocr_settings))
            # joins innermost item by newlines, gets a list of multiple paragraphs
            result = [' '.join(x) for x in result]

        # single character
        elif segmode == 'char':
            # no cropping nedded
            result = _img_to_text(self.item_img, self.ocr_settings)

        # single line/ word trimmed
        else:
            coords = trim_line(self.item_img, LINE_OPEN_KERNEL_SIZE, LOWER_LW_LIMIT)
            img_list = _nd_crop(self.item_img, coords)
            # assigns to object variable
            self.item_img = img_list
            result = _img_to_text(self.item_img, self.ocr_settings)

        return result

    def rec_img(self):
        """
            public method, handles edge cases and return recognized text results
        :return: list of recognized results:
                for a 'doc' level item, for example, share_addr with two addrs, will get result ['', '']
                for 'blk', 'line' level items, for example, company_addr & 'director_addr_1', will get ['']
        """
        if 'share_addr' == self.key:
            coords, v_borders = seg_doc(self.item_img, PARA_OPEN_KERNEL_SIZE, LINE_OPEN_KERNEL_SIZE, LOWER_PW_LIMIT,
                                        LOWER_LW_LIMIT)
            self.parent.v_borders = v_borders

            result = []
            for i in range(len(coords)):
                img_list = _nd_crop(self.item_img, coords[i])
                # assigns to object variable
                result.append(_img_to_text(img_list, self.ocr_settings))
            # joins innermost item by newlines, gets a list of multiple paragraphs
            result = [filter_non_ascii_chars(' '.join(x)) for x in result]
            return result

        # Other shareholder infos, only fields that need the v_border parameter
        if 'share_name' == self.key or 'share_amount' == self.key:
            # first use v_borders to segment by shareholder, then do further segmentation
            if self.parent.v_borders is None:
                return []
            result = []
            w, h = self.item_img.size
            for border in self.parent.v_borders:
                blk = self.item_img.crop((0, border[0], w, border[1]))
                coords = seg_para(blk, LINE_OPEN_KERNEL_SIZE, LOWER_LW_LIMIT)
                img_list = _nd_crop(blk, coords)
                result.append(_img_to_text(img_list, self.ocr_settings))
            # joins innermost item by newlines, gets a list of multiple paragraphs
            result = [filter_non_ascii_chars(' '.join(x)) for x in result]
            return result

        # only field where SEG and PSM does not match
        # should only return a single
        elif 'cn_name' in self.key:
            coords = seg_word(self.item_img, CHAR_DILATE_KERNEL_SIZE, LOWER_CW_LIMIT)
            img_list = _nd_crop(self.item_img, coords)
            self.item_img = img_list
            result = _img_to_text(self.item_img, self.ocr_settings)
            result = [''.join(list(chain(*result)))]
            return result

        # normal fields
        else:
            result = self._get_item_text(self.ocr_settings['SEG'])
        return result
