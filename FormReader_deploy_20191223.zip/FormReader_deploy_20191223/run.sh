#/bin/sh
source ~/conda.sh
conda activate form2
for f in `cat list.txt`; do python FormReader.py $f out NAR1; done
