"""
    "Main" file for the entire project, initialize class for each documents and writes out results.
"""

import os.path
from argparse import ArgumentParser

from NAR1.NAR1Document import PDFReadError, ResultWriteError, NAR1Document


class DocTypeUnsupportedError(Exception):
    pass


def main(in_path, out_path, doc_type):
    read_form(in_path, out_path, doc_type)


def read_form(in_path, out_path, doc_type):
    if not os.path.isfile(in_path):
        # raise FileNotFoundError("The provided input file does not exist.")
        return 1

    # creates output directory if the specified one does no exist
    if not os.path.exists(out_path):
        try:
            os.makedirs(out_path)
        except FileExistsError:
            # directory already exists due to race condition
            pass

    # appends backslash if there is none
    if not out_path.endswith(os.sep):
        out_path = out_path + os.sep

    if doc_type == 'NAR1':
        nar1 = NAR1Document(input_path=in_path, output_path=out_path)
        try:
            nar1.recognize()
        except PDFReadError:
            # The provided pdf file cannot be correctly read
            return 2
        except ResultWriteError:
            return 4
    else:
        # Unseen format
        # raise DocTypeUnsupportedError('{} is not supported yet'.format(doc_type))
        return 3

    # process finished without error
    return 0


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument("in_path", help="Input PDF path", type=str)
    parser.add_argument("out_path", help="Output Json path", type=str)
    parser.add_argument("doc_type", help="Input document type, currently only supports NAR1 and NNC1", type=str)

    args = parser.parse_args()
    main(args.in_path, args.out_path, args.doc_type)
    exit()
