import os
PWD = os.getcwd()

TESSDATA_PATH = 'models/tessdata/'

# SIFT REGISTRATION PARAMETERS
# ratio for Lowe's test when match SIFT feature points
LOWE_RATIO = 0.8
# the number of iterations permitted for RANSAC when finding transformation
RANSAC_ITER_NUM = 2000
