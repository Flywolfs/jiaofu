# -*- encoding: utf-8 -*-
from django.http import FileResponse,HttpResponse,StreamingHttpResponse
from django.shortcuts import render
from ..models import OverallProcess,GovDoc,Company,Person,PersonalNews
from wsgiref.util import FileWrapper
import os,tempfile
from VBService.views import static_path
import traceback
import re
import os
import datetime
import pdfkit
from json2html import *

PDF_loc = "/home/ubuntu/vb_migrate/server_migrate/predeploy/data/contents/gov/"

def download(request):
    if request.method == "GET":
        session_id = request.GET.get("session_id")
        type = request.GET.get("type")
        if type == "ocr":
            try:
                op = OverallProcess.objects.get(session_id=session_id)
                if op:
                    docs = GovDoc.objects.filter(overall_process=op)
                    comps = Company.objects.filter(overall_process=op)
                    #只有icris online
                    if docs.exists() and len(docs) == 1 and docs[0].doc_name=="online_view":
                        print("only has icris")
                        comp = comps[0]
                        cwd = os.getcwd()
                        os.chdir(PDF_loc+comp.en_name)
                        # generate compliance file for comp without NAR1
                        doc = docs[0]
                        compliance_check = {"session id": session_id, "start time": str(op.record_created_time)+" UTC Time",
                                            "end time": str(doc.record_created_time)+" UTC Time", "icris ocr file record": []}
                        compliance_check["icris ocr file record"].append(
                                {"filename": doc.doc_name, "path": doc.ocr_output_location})
                        html = json2html.convert(json=compliance_check)
                        pdfkit.from_string(html, 'compliance_check.pdf')
                        en_name = re.sub(r'[&\s;,\.()]', '_', comp.en_name)
                        zipname = comp.cr_num+"-"+en_name+".zip"
                        print("zip文件名:" + zipname)
                        print("zip -r "+zipname+" Document\ Image* icris_online.html icris_online.json compliance_check.pdf")
                        if not os.path.exists(zipname):
                            os.system("zip -r "+zipname+" Document\ Image* icris_online.html icris_online.json compliance_check.pdf")
                        response = StreamingHttpResponse(file_iterator(os.getcwd() + "/" + zipname))
                        response['Content-Type'] = 'application/zip'
                        response['Content-Disposition'] = 'attachment;filename="'+zipname+'"'
                        os.chdir(cwd)
                        return response
                    #有NAR1
                    elif docs.exists() and len(docs) > 1:
                        print("has icris and nar1")
                        doc = None
                        for doc_record in docs:
                            if "nar1" in doc_record.doc_name.lower():
                                doc = doc_record
                        comp = comps[0]
                        doc_location = doc.doc_file_location
                        ocr_location = doc.ocr_output_location
                        if doc and doc_location:
                            cwd = os.getcwd()
                            os.chdir(doc_location)
                            os.chdir("..")
                            if ocr_location:
                                ocr_location = "/".join(ocr_location.split("/")[-2:])
                            en_name = re.sub(r'[&\s;,\.()]', '_', comp.en_name)
                            zipname = comp.cr_num + "-" + en_name + ".zip"
                            print("zip文件名:" + zipname)
                            print("zip -r " + zipname + " Document\ Image* icris_online.html icris_online.json compliance_check.pdf ../../" + ocr_location)
                            if not os.path.exists(zipname):
                                os.system("zip -r " + zipname + " Document\ Image* icris_online.html icris_online.json compliance_check.pdf ../../" + ocr_location)
                            response = StreamingHttpResponse(file_iterator(os.getcwd() + "/" + zipname))
                            response['Content-Type'] = 'application/zip'
                            response['Content-Disposition'] = 'attachment;filename="' + zipname + '"'
                            os.chdir(cwd)
                            return response
                    #对于只有NAR没有icris online的老记录，也要支持下载
                    elif comps.exists():
                        print("old guy")
                        comp = comps[0]
                        en_name = comp.en_name
                        if os.path.exists(PDF_loc+en_name):
                            cwd = os.getcwd()
                            os.chdir(PDF_loc+en_name)
                            en_name = re.sub(r'[&\s;,\.()]', '_', comp.en_name)
                            zipname = comp.cr_num + "-" + en_name + ".zip"
                            print("zip文件名:" + zipname)
                            if not os.path.exists(zipname):
                                os.system("zip -r " + zipname + " Document\ Image*")
                            response = StreamingHttpResponse(file_iterator(os.getcwd() + "/" + zipname))
                            response['Content-Type'] = 'application/zip'
                            response['Content-Disposition'] = 'attachment;filename="' + zipname + '"'
                            os.chdir(cwd)
                            return response
                        else:
                            ctx = {}
                            ctx['return_code'] = session_id + " has no file"
                            return render(request, 'web/api2.html', ctx)
                else:
                    ctx = {}
                    ctx['return_code'] = session_id + " not exist"
                    return render(request,'web/api2.html',ctx)
            except Exception as e:
                print(traceback.print_exc())
                ctx = {}
                ctx['return_code'] = session_id + " maybe not correct, please check or contact administrator."
                return render(request, 'web/api2.html', ctx)
        elif type == "ner":
            try:
                print(session_id)
                op = OverallProcess.objects.get(session_id=session_id)
                if op:
                    person = Person.objects.get(overall_process_as_shareholder=op)
                    person_id = person.id
                    person_date = str(person.record_created_time).split(' ')[0]
                    news = PersonalNews.objects.filter(person_id=person_id)
                    person_folder = ""
                    ner_folder = ""
                    for one in news:
                        if one.news_file_location:
                            person_folder = one.news_file_location
                            ner_folder = one.ner_output_location
                            break
                    if person_folder != "" and ner_folder !="" and ner_folder:
                        person_folder = re.sub(r"\/\d+.txt","",person_folder)
                        cwd = os.getcwd()
                        os.chdir(person_folder)
                        if ner_folder:
                            ner_folder = "/".join(ner_folder.split("/")[-4:-1])
                        en_name = re.sub(r'[&\s;,\.()]', '_', person.en_name)
                        zipname = session_id+"-"+en_name+".zip"
                        print("zip文件名:" + zipname)
                        if not os.path.exists(zipname):
                            os.system("zip -r "+zipname+" * ../../../"+ner_folder)
                        response = StreamingHttpResponse(file_iterator(os.getcwd()+"/"+zipname))
                        response['Content-Type'] = 'application/zip'
                        response['Content-Disposition'] = 'attachment;filename="' + zipname + '"'
                        os.chdir(cwd)
                        return response
                    # 如果文件夹存在且不为空
                    elif os.path.exists(static_path.news_folder+person_date+"/"+person.en_name) and os.listdir(static_path.news_folder+person_date+"/"+person.en_name):
                        cwd = os.getcwd()
                        os.chdir(static_path.news_folder+person_date+"/"+person.en_name)
                        en_name = re.sub(r'[&\s;,\.()]', '_', person.en_name)
                        zipname = session_id + "-" + en_name + ".zip"
                        print("zip文件名:" + zipname)
                        if not os.path.exists(zipname):
                            os.system("zip -r " + zipname + " * ")
                        response = StreamingHttpResponse(file_iterator(os.getcwd() + "/" + zipname))
                        response['Content-Type'] = 'application/zip'
                        response['Content-Disposition'] = 'attachment;filename="' + zipname + '"'
                        os.chdir(cwd)
                        return response
                    else:
                        ctx = {}
                        ctx['return_code'] = session_id + " has no file"
                        return render(request, 'web/api6.html', ctx)
                else:
                    ctx = {}
                    ctx['return_code'] = session_id + " not exist"
                    return render(request, 'web/api6.html', ctx)

            except Exception as e:
                print(traceback.print_exc())
                ctx = {}
                ctx['return_code'] = session_id + " maybe not correct, please check or contact administrator."
                return render(request, 'web/api6.html', ctx)

def file_iterator(file_name, chunk_size=512):
    with open(file_name, 'rb') as f:
        while True:
            c = f.read(chunk_size)
            if c:
                yield c
            else:
                break
