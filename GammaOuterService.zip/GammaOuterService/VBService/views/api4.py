from django.http import HttpResponse
from django.shortcuts import render
from ..models import OverallProcess
import json
import time
import urllib.parse

# Api 4
def get_ner_results(request):
    if 'session_id_list' in request.POST:
        session_id_list = request.POST.getlist('session_id_list')
        business_type = request.POST.getlist('business_type')
        ctx = {}
        ctx['results_list'] = []
        ctx['return_code'] = '0000'
        for session_id in session_id_list:
            ops = OverallProcess.objects.filter(session_id=session_id)
            if len(ops)>0:  # check whether the overall process in this session_id exist
                # TODO 已经交换sme和retail
                op = ops[0]
                if business_type[0] == 'retail' and op.gov_crawled_status and op.gov_ocr_status \
                        and op.is_shareholders_confirm and op.is_all_ner_finished:
                    info_retrieve_dict = {}
                    info_retrieve_dict['session_id'] = session_id
                    info_retrieve_dict['company_ner_list'] = []
                    info_retrieve_dict['company_ner_list_cn'] = []
                    info_retrieve_dict['shareholders_list'] = []
                    company_news_links = op.comp_application.comp_news_links.all()
                    for news in company_news_links:
                        ner_result_dict = {}
                        ner_result_dict['comp_name'] = news.comp_name
                        ner_result_dict['news_title'] = news.news_title
                        ner_result_dict['news_file_location'] = news.news_file_location
                        ner_result_dict['ner_output_location'] = news.ner_output_location
                        ner_result_dict['crawl_start_time'] = news.crawl_start_time
                        ner_result_dict['crawl_end_time'] = news.crawl_end_time
                        if all(ord(c) < 128 for c in ner_result_dict['comp_name']):
                            info_retrieve_dict['company_ner_list'].append(ner_result_dict)
                        else:
                            info_retrieve_dict['company_ner_list_cn'].append(ner_result_dict)

                    for shareholder in op.shareholders.all():
                        personal_news_links = shareholder.personal_news_links.all()
                        retrieve_ner_dict = {}
                        retrieve_ner_dict['shareholder_ner_list'] = []
                        retrieve_ner_dict['shareholder_ner_list_cn'] = []
                        for news in personal_news_links:
                            ner_result_dict = {}
                            ner_result_dict['person_name'] = news.person_name
                            ner_result_dict['news_title'] = news.news_title
                            ner_result_dict['news_file_location'] = news.news_file_location
                            ner_result_dict['ner_output_location'] = news.ner_output_location
                            ner_result_dict['crawl_start_time'] = news.crawl_start_time
                            ner_result_dict['crawl_end_time'] = news.crawl_end_time
                            if all(ord(c) < 128 for c in ner_result_dict['person_name']):
                                retrieve_ner_dict['shareholder_ner_list'].append(ner_result_dict)
                            else:
                                retrieve_ner_dict['shareholder_ner_list_cn'].append(ner_result_dict)
                        info_retrieve_dict['shareholders_list'].append(retrieve_ner_dict)
                    ctx['results_list'].append(info_retrieve_dict)
                elif business_type[0] == "sme" and op.is_shareholders_confirm and op.is_all_ner_finished:
                    info_retrieve_dict = {}
                    info_retrieve_dict['session_id'] = session_id
                    info_retrieve_dict['shareholders_list'] = []
                    for shareholder in op.shareholders.all():
                        personal_news_links = shareholder.personal_news_links.all()
                        retrieve_ner_dict = {}
                        retrieve_ner_dict['shareholder_ner_list'] = []
                        retrieve_ner_dict['shareholder_ner_list_cn'] = []
                        for news in personal_news_links:
                            if news.news_ner_status and not if_ner_location_empty(news.ner_output_location):
                                ner_result_dict = {}
                                ner_result_dict['person_name'] = news.person_name
                                ner_result_dict['news_title'] = news.news_title
                                ner_result_dict['link'] = news.link
                                ner_output_location = news.ner_output_location.split("path=")[0]+'path='+urllib.parse.quote(news.ner_output_location.split("path=")[1])
                                ner_result_dict['ner_output_location'] = ner_output_location
                                ner_result_dict['crawl_start_time'] = news.crawl_start_time
                                ner_result_dict['crawl_end_time'] = news.crawl_end_time
                                if all(ord(c) < 128 for c in ner_result_dict['person_name']):
                                    retrieve_ner_dict['shareholder_ner_list'].append(ner_result_dict)
                                else:
                                    retrieve_ner_dict['shareholder_ner_list_cn'].append(ner_result_dict)
                        info_retrieve_dict['shareholders_list'].append(retrieve_ner_dict)
                    ctx['results_list'].append(info_retrieve_dict)
                else:
                    ctx["return_code"] = "Still in processing"
                    return render(request, 'web/api6.html', ctx)
            else:
                ctx["return_code"] = "No such session id"
                return render(request, 'web/api6.html', ctx)

        # return HttpResponse(json.dumps(ctx))
        # return render(request, 'web/api4.html', ctx)
        return render(request, 'web/api6.html', ctx)
    else:
        return HttpResponse('Bad Request')

def if_ner_location_empty(loc):
    if loc is None or loc == "":
        return True
    else:
        return False

