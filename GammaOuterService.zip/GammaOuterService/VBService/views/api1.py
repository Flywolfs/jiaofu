from django.shortcuts import render
from django.db.models import Max
from ..models import OverallProcess, Person, Company
import json
import requests
import sqlite3
import traceback
from django.utils import timezone

SME = "001"
# Api 1
# TODO change def name
def check_company_num(request):
    # if 'channel_id' and 'cr_num' and 'user_name_en' in request.POST:
    if 'cr_num' and 'comp_name_en' and 'comp_name_cn' and 'person_name_en' in request.POST:
        print("启动流程")
        channel_id = '001'
        cr_num = request.POST.get('cr_num')
        user_name_en = request.POST.get('person_name_en')
        comp_name_en = request.POST.get('comp_name_en')
        comp_name_cn = request.POST.get('comp_name_cn')
        print(request.POST)
        # user_name_cn = request.POST.get('user_name_cn')

        # 1st checking-search in cr database, 'switch' is just for testing the process smoothly since the program
        # will skip crawler searching if it is False,
        # TODO　去掉数据库查验
        # comp_exist = __search_comp_number_by_db(cr_num=cr_num, switch=False)
        ctx = {}
        # ctx.update(csrf(request))

        # 2nd checking-trigger spider to search company online
        # TODO:need return comp name from cr website
        # if not comp_exist['exist']:
        last_comp_op = None
        last_op = OverallProcess.objects.last()
        for i in range(0,len(OverallProcess.objects.all())):
            comp_search = Company.objects.filter(overall_process=last_op)
            if len(comp_search) > 0:
                last_comp_op = last_op
                break
            else:
                last_op_f = OverallProcess.objects.filter(session_id=last_op.session_id-1)
                if len(last_op_f) > 0:
                    last_op = last_op_f[0]
        print("上一个查询公司的session id:"+str(last_comp_op.session_id))
        time_fly = (timezone.now() - last_comp_op.record_created_time).total_seconds()
        if last_comp_op is None or time_fly>420:
            comp_exist = __request_crawler(function='check_comp_exist',
                                               para={'cr_num': cr_num},
                                               switch=False)  # = start CR online check
            if comp_exist['exist']:
                # if chinese or english name is '', then these two fields will be filled in when the spider crawls the
                # gov docs
                # comp_name_en = comp_exist['comp_en_name']
                # comp_name_cn = comp_exist['comp_cn_name']
                # TODO generate session_id and an overall process record
                records = OverallProcess.objects.all()
                if records.count() != 0:
                    max_session_id = records.aggregate(Max('session_id'))
                    session_id = max_session_id['session_id__max'] + 1
                else:
                    session_id = channel_id + '0000000001'
                # TODO add one stack for saving record
                op = OverallProcess(session_id=int(session_id), comp_exist=True)
                op.save()
                new_session_id = SME + str(op.id).zfill(10)
                OverallProcess.objects.filter(id=op.id).update(session_id=new_session_id)
                # person = Person(en_name=user_name_en, cn_name=user_name_cn, overall_process_as_applicant=op)
                person = Person(en_name=user_name_en, overall_process_as_applicant=op)
                person.save()

                # company = Company(cr_num=cr_num, en_name=comp_name_en, overall_process=op)
                company = Company(cr_num=cr_num, overall_process=op,en_name=comp_name_en)
                company.save()
                # TODO fix company chinese name

                # set retry time for 3
                retry_times = 3
                crawl_gov_result = {'exec_succ': False}
                crawl_neg_result = {'exec_succ': False}
                for i in range(0, retry_times):
                    try:
                        # start crawl engine to crawl gov documents
                        if not crawl_gov_result['exec_succ']:
                            crawl_gov_result = __request_crawler(function='gov', para={'comp_cn_name': comp_name_cn,
                                                                                       'comp_en_name': comp_name_en,
                                                                                       'cr_num':cr_num,
                                                                                       'session_id': session_id},
                                                                 switch=False)
                        # start crawl engine to crawl negative news
                        # if not crawl_neg_result['exec_succ']:
                        #     crawl_neg_result = __request_crawler(function='neg', para={'comp_cn_name': comp_name_cn,
                        #                                                                'comp_en_name': comp_name_en,
                        #                                                                'shareholders':"",
                        #                                                                'type':1,
                        #                                                                'session_id': session_id},
                        #                                          switch=False)
                        # comp exist and crawl engine started succ
                        print("crawl_gov_result is" + str(crawl_gov_result))
                        # print("crawl_neg_result is" + str(crawl_neg_result))
                        # if crawl_gov_result['exec_succ'] and crawl_neg_result['neg_start_status'][0]['exec_succ']:
                        #     ctx['session_id'] = str(int(session_id))
                        #     ctx['return_code'] = '0000'  # Exist and crawl engine started
                        #     # return HttpResponse(json.dumps(ctx))
                        #     return render(request, 'web/api1.html', ctx)
                        if crawl_gov_result['exec_succ']:
                            ctx['session_id'] = str(int(session_id))
                            ctx['return_code'] = '0000'  # Exist and crawl engine started
                            # return HttpResponse(json.dumps(ctx))
                            return render(request, 'web/api1.html', ctx)
                    except Exception as e:
                        print(traceback.print_exc())
                # comp exist but crawl engine start failed for 3 times
                ctx['session_id'] = session_id
                ctx['return_code'] = '0002'
                # return HttpResponse(json.dumps(ctx))
                return render(request, 'web/api1.html', ctx)
            else:
                # comp not exist
                ctx['session_id'] = 'Null'
                ctx['return_code'] = '0001'  # Not exist
                # return HttpResponse(json.dumps(ctx))
                return render(request, 'web/api1.html', ctx)
        else:
            ctx['session_id'] = 'Null'
            ctx['return_code'] = '两次请求间隔太短，请等待约'+str(round(7-time_fly/60,1))+'分钟后再进行请求。'
            return render(request, 'web/api1.html',ctx)
    else:
        # return HttpResponse('Bad Request')
        return render(request, 'web/api1.html')



# TODO Wait encapsulating
def __search_comp_number_by_db(cr_num=None, switch=False):
    result = dict()
    if switch:
        result['exist'] = True
        result['comp_name_en'] = ''
        result['comp_name_cn'] = ''
        return result
    else:
        conn = sqlite3.connect('../../sme.db')
        c = conn.cursor()
        cursor = c.execute('SELECT english_name, chinese_name FROM sme_comps WHERE cr_num=' + str(cr_num))
        comp_name_en = ''
        comp_name_cn = ''
        for row in cursor:
            comp_name_en = row[0]
            comp_name_cn = row[1]
        if comp_name_en == '' and comp_name_cn == '':
            result['exist'] = False
            return result
        else:
            result['exist'] = True
            result['comp_name_en'] = comp_name_en
            result['comp_name_cn'] = comp_name_cn
            return result


def __request_crawler(function=None, para=None, switch=False):
    # 检查公司存在之后需要返回公司中英文名
    if function == 'check_comp_exist':
        if switch:
            result = {'exist': False, 'comp_name_en': '', 'comp_name_cn': ''}
            return result
        else:
            url = 'http://localhost:8002/crawler/checkcomp/'
            para = json.dumps(para)
            result = requests.post(url=url, data=para)
            result = json.loads(result.text)
            print(result)
            return result
    elif function == 'gov':
        if switch:
            result = {'exec_succ': True}
            return result
        else:
            # para = {'company':company,'session_id':session_id}
            print("请求购买和下载")
            url = 'http://localhost:8002/crawler/buyanddownload/'
            para = json.dumps(para)
            result = requests.post(url=url, data=para)
            print(result.text)
            result = json.loads(result.text)
            print(result)
            return result
    elif function == 'neg':
        if switch:
            result = {'exec_succ': True}
            return result
        else:
            # para = {'company':(comp_name_en,comp_name_cn),'person': (user_name_en, user_name_cn),'session_id':session_id}
            url = 'http://localhost:8002/crawler/negtivenews/'
            para = json.dumps(para)
            result = requests.post(url=url, data=para)
            result = json.loads(result.text)
            return result

