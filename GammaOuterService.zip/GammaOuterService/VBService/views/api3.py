from django.http import HttpResponse
from ..models import OverallProcess, Person
import json
import requests

# SME = "001"
RETAIL = "001"
# Api 3
def confirm_shareholders(request):
    if request.method != 'POST':
        return HttpResponse('Bad Request: Not a POST method')
    var = json.loads(request.body)
    print(var)
    '''
    Json format example in HttpRequest
    {
	    "session_id": 100000000001,
	    "shareholders_list": [
	        {"user_name_en":"John Smith","user_name_cn":""},
			{"user_name_en":"Donnie Azoff","user_name_cn":""},
			{"user_name_en":"Chuck Bass","user_name_cn":""}
		]
    }
    '''
    # TODO 已经把sme和retail换顺序
    if var['business_type'] == 'retail':
        # print(var['session_id'])
        # print(var['shareholders_list'])
        if 'session_id' in var and 'shareholders_list' in var:
            session_id = var['session_id']
            shareholders_list = var['shareholders_list']
            op = OverallProcess.objects.get(session_id=session_id)
            if op.is_shareholders_confirm:
                return HttpResponse('Bad Request: Shareholders have already been confirmed')
            shareholders = list()
            comp_cn_name = op.comp_application.cn_name
            comp_en_name = op.comp_application.en_name
            for shareholder_dict in shareholders_list:
                # Were the person matched as an applicant,
                # we would retrieve this person and set him/her as a shareholder
                if shareholder_dict['user_name_en'] == op.person_application.en_name:
                    temp_shareholder = op.person_application
                    temp_shareholder.overall_process_as_shareholder = op
                # On the contrary, we would create a new person as a shareholder
                else:
                    temp_shareholder = Person(en_name=shareholder_dict['user_name_en'],
                                              cn_name=shareholder_dict['user_name_cn'],
                                              overall_process_as_shareholder=op, )
                temp_shareholder.save()
                shareholders.append({"en_name": shareholder_dict['user_name_en'], "cn_name": shareholder_dict['user_name_cn']})
            # TODO determine whether 'is_shareholders_confirm' should be update here?
            op.is_shareholders_confirm = True
            op.save()
            # TODO confirm type 0 is ok or not?
            #  and if/else control the return_code
            data = {"session_id":session_id,"type":0,"shareholders":shareholders,"comp_cn_name":comp_cn_name,"comp_en_name":comp_en_name}
            url = 'http://localhost:8002/crawler/negtivenews/'
            para = json.dumps(data)
            result = requests.post(url=url, data=para)
            result_txt = json.loads(result.text)
            print(result_txt)
            ctx = {}
            ctx['return_code'] = '0000'
            ctx['session_id'] = var['session_id']
            return HttpResponse(json.dumps(ctx))
        return HttpResponse('Bad Request: No enough parameters')
    elif var['business_type'] == 'sme':
        if 'shareholders_list' in var:
            if len(var['shareholders_list']) == 1:
                shareholders_list = var['shareholders_list']
                shareholders = list()
                new_session_id = ''
                # records = OverallProcess.objects.all()
                # if records.count() != 0:
                #     max_session_id = records.aggregate(Max('session_id'))
                #     new_session_id = max_session_id['session_id__max'] + 1
                # else:
                #     # TODO 这里有一个bug,如果retail先发起，会造成SME的id也会从002开始，后续需要应对sessionid新建问题
                #     new_session_id = '002' + '00000000001'
                try:
                    op = OverallProcess(session_id=0, comp_exist=True, gov_crawled_status=True,
                                        gov_ocr_status=True,is_shareholders_confirm=True)
                    op.save()
                    new_session_id = RETAIL+str(op.id).zfill(10)
                    OverallProcess.objects.filter(id=op.id).update(session_id=new_session_id)
                    for shareholder_dict in shareholders_list:
                        temp_shareholder = Person(en_name=shareholder_dict['user_name_en'],
                                                  cn_name=shareholder_dict['user_name_cn'],
                                                  overall_process_as_shareholder=op, )
                        temp_shareholder.save()
                        shareholders.append(
                            {"en_name": shareholder_dict['user_name_en'], "cn_name": shareholder_dict['user_name_cn']})

                    data = {"session_id": new_session_id, "type": 2, "shareholders": shareholders, "comp_cn_name": "",
                            "comp_en_name": ""}
                    url = 'http://localhost:8002/crawler/negtivenews/'
                    para = json.dumps(data)
                    result = requests.post(url=url, data=para)
                    result_txt = json.loads(result.text)
                    print(result_txt)
                    ctx = {}
                    ctx['return_code'] = '0000'
                    ctx['session_id'] = int(new_session_id)
                    return HttpResponse(json.dumps(ctx))
                except Exception as e:
                    print("error")
                    print(e)
            else:
                return HttpResponse('Bad Request: Error Input')
        return HttpResponse('Bad Request: No enough parameters')

def test_function(request):
    var = json.loads(request.body.decode())
    print('success')
    ctx = {}
    ctx['return_code'] = '0000'
    ctx['session_id'] = var['session_id']
    return HttpResponse(json.dumps(ctx))
