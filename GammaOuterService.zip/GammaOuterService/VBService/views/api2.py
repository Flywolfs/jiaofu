from django.http import HttpResponse
from django.shortcuts import render
from ..models import OverallProcess
import json
import traceback
import urllib.parse


# Api 2
def get_ocr_results(request):
    if 'session_id_list' in request.POST:
        session_id_list = request.POST.getlist('session_id_list')
        ctx = {}
        ctx['results_list'] = []
        ctx['return_code'] = 'success'

        for session_id in session_id_list:
            try:
                ops = OverallProcess.objects.filter(session_id=session_id)
                if len(ops)>0:  # check whether the overall process in this session_id exist
                    op = ops[0]
                    if op.gov_crawled_status and op.gov_ocr_status:
                        # TODO retrieve gov doc record from db
                        gd_list = op.gov_docs_crawling.all()
                        info_retrieve_dict = {}
                        info_retrieve_dict['session_id'] = op.session_id
                        info_retrieve_dict['ocr_result_list'] = []
                        online_view_path = ""
                        for gd in gd_list:
                            ocr_result_dict = {}
                            if gd.doc_name == "online_view":
                                online_view_path = gd.ocr_output_location
                            else:
                                ocr_result_dict['ocr_status'] = gd.ocr_status
                                ocr_output_location = gd.ocr_output_location.split("path=")[0]+'path='+urllib.parse.quote(gd.ocr_output_location.split("path=")[1])
                                ocr_result_dict['ocr_output_location'] = ocr_output_location
                                ocr_result_dict['doc_name'] = gd.doc_name
                                info_retrieve_dict['ocr_result_list'].append(ocr_result_dict)
                        ctx['results_list'].append(info_retrieve_dict)
                        online_view_path_parts = online_view_path.split("path=")
                        online_view_path = online_view_path_parts[0]+'path='+urllib.parse.quote(online_view_path_parts[1])
                        ctx['online_view_path'] = online_view_path
                        # TODO determine whether 'gov_ocr_status' should be update here?
                        # op.gov_ocr_status = True
                        # op.save()
                    else:
                            ctx['return_code'] = session_id+" is still in processing, please check again later."
                else:
                    ctx['return_code'] = session_id + " not correct, please check."
            except Exception as e:
                print(traceback.print_exc())
                ctx['return_code'] = session_id+" maybe not correct, please check."

        # return HttpResponse(json.dumps(ctx))
        return render(request, 'web/api2.html', ctx)
    else:
        # return HttpResponse('Bad Request')
        return render(request, 'web/api2.html')

