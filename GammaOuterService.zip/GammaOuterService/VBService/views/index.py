from django.shortcuts import render
def index(request):
    context = {
        "index":"index"
    }
    return render(request,'web/index.html')

def api1(request):
    return render(request, 'web/api1.html')

def api2(request):
    return render(request, 'web/api2.html')

def api3(request):
    return render(request, 'web/api3.html')

def api4(request):
    return render(request, 'web/api4.html')

def api5(request):
    return render(request, 'web/api5.html')

def api6(request):
    return render(request, 'web/api6.html')