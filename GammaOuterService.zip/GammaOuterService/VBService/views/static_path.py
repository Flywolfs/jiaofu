# -*- encoding: utf-8 -*-
'''
@File    :   static_path.py    
@Author :   Chi Zhang
'''
gov_db = "/home/ubuntu/vb_migrate/server_migrate/predeploy/data/db/gov/sme.db"
news_folder = "/home/ubuntu/vb_migrate/server_migrate/predeploy/data/contents/news/"
