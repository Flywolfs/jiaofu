from django.apps import AppConfig


class VBServiceConfig(AppConfig):
    name = 'VBService'
