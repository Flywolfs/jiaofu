from django.test import TestCase

# Create your tests here.
from .models import Person, PersonalNews

def test_outerapi3_with_valid_input():
    pass

def test_outerapi3_with_invalid_business_type():
    pass

def test_outerapi3_with_invalid_session_id():
    pass

def test_outerapi3_with_empty_shareholder_list():

