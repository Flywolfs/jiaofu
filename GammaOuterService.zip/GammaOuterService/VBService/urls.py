from django.urls import path

from .views import api1,api2,api3,api4,index,show_data,download

urlpatterns = [
    path(r'check_company_num/', api1.check_company_num, name="check_company_num"),
    path(r'get_ocr_results/', api2.get_ocr_results, name="get_ocr_results"),
    path(r'confirm_shareholders/', api3.confirm_shareholders, name="confirm_shareholders"),
    path(r'get_ner_results/', api4.get_ner_results, name="get_ner_results"),
    path(r'',index.index,name="index"),
    path(r'api1_page/',index.api1,name="api1_page"),
    path(r'api2_page/',index.api2,name="api2_page"),
    path(r'api3_page/',index.api3,name="api3_page"),
    path(r'api4_page/',index.api4,name="api4_page"),
    path(r'api5_page/',index.api5,name="api5_page"),
    path(r'api6_page/',index.api6,name="api6_page"),
    path(r'show_data/',show_data.index,name="show_data"),
    path(r'download/',download.download,name="download")
]

