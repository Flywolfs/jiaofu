from textblob import TextBlob
import json

class NER():
    def news_ana(this,newslocation,nerout):
        text = open(newslocation).read().splitlines()
        n = 1
        error = 0
        neg_para = 0
        ifsucc = True
        for para in text:
            try:
                blob = TextBlob(para)
                NegPoints = blob.sentiment[0]
                if NegPoints < 0:
                    neg_para += 1
                    data = {'Neg Para':n, 'NegPoints':NegPoints, 'Subjectivity':blob.sentiment[1],}
                    f = open(nerout,'a+')
                    f.write(json.dumps(data))
                    f.close()
            except Exception as e:
                error += 1
            n = n+1
        if error == n:
            return {"if_succ": not ifsucc, "neg_count":neg_para}
        else:
            return {"if_succ": ifsucc, "neg_count":neg_para}
