from django.urls import path
from . import views

urlpatterns = [
    path('nernegnews/', views.newsner,name="newsner"),
]