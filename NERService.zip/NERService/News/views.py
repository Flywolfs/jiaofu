from django.shortcuts import render
from django.http import HttpResponse
import json
import requests
from News.NegNews_v2 import NewsJudge
from News import static_path
import datetime
import os
import shutil
# Create your views here.

SUCC = 200
# API1
def newsner(request):
    if request.method == "POST":
        ner = NewsJudge()
        print("准备启动NER")
        ner_paras = json.loads(request.body.decode())
        print("ner_paras:"+str(ner_paras))
        session_id = ner_paras["session_id"]
        type = ner_paras["type"]
        news_items = ner_paras["ner_items"]
        person_name = ner_paras["person_name"]
        comp_name = ner_paras["comp_name"]
        result = {"session_id":session_id,"type":type,"person_name":person_name,"comp_name":comp_name}
        output_loc = ""
        # retail
        if comp_name == "" and person_name != None:
            output_loc = static_path.ner_location + str(datetime.date.today()) + "/" + person_name + "/"
        # comp+person
        elif comp_name != "" or person_name != None:
            output_loc = static_path.ner_location + str(datetime.date.today()) + "/" + comp_name + "_" + person_name + "/"
        # comp
        elif comp_name != "" or person_name == None:
            output_loc = static_path.ner_location + str(datetime.date.today()) + "/" + comp_name + "/"
        detail_list = []
        total_news = 0
        error = 0
        original_output_loc = output_loc
        if not os.path.exists(static_path.static_prefix_local+output_loc):
            os.makedirs(static_path.static_prefix_local+output_loc)
        else:
            shutil.rmtree(static_path.static_prefix_local+output_loc)
            os.makedirs(static_path.static_prefix_local + output_loc)
        for item in news_items:
            result_list = []
            news_list = item["news_list"]
            for news in news_list:
                total_news += 1
                news_loc = news["news_file_location"]
                output_loc += news_loc.split("/")[-1]
                remote_output_loc = output_loc
                output_loc = static_path.static_prefix_local + output_loc[0:-3]+"html"
                link = news["link"]
                # TODO exec NER and update result and judge return code
                ner_result = ner.news_ana(news_loc,output_loc)
                remote_output_loc = static_path.static_prefix_remote + remote_output_loc[0:-3]+"html"
                if ner_result["if_succ"] and ner_result["neg_count"] > 0:
                    result_list.append({"link":link,"ner_output_location":remote_output_loc,"if_neg":True})
                elif ner_result["if_succ"] and ner_result["neg_count"] == 0:
                    result_list.append({"link": link, "ner_output_location": remote_output_loc, "if_neg": False})
                elif not ner_result["if_succ"]:
                    error += 1
                output_loc = original_output_loc
            detail_list.append({"keyword":item["keyword"],"result_list":result_list})
        if error < total_news or total_news == 0:
            result["return_code"] = 200
            result["detail_list"] = detail_list
        else:
            result["return_code"] = 400
        print(result)
        response = requests.post("http://localhost:8001/vbservice/inner/nerresult/",json.dumps(result))
        print(response)
        return HttpResponse("Success handling NER")
    else:
        return HttpResponse("Bad Request!")
