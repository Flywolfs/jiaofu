# -*- encoding: utf-8 -*-
'''
@File    :   static_path.py    
@Author :   Chi Zhang
'''
static_prefix_local = "/home/ubuntu/vb_migrate/server_migrate/predeploy/data/"
static_prefix_remote = "http://18.163.120.254:8000/vbapi/show_data/?path="
