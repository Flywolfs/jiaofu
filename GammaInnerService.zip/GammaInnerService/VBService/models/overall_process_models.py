from django.db import models


class OverallProcess(models.Model):
    session_id              = models.BigIntegerField(default=-1)
    comp_exist              = models.BooleanField(default=True)
    record_created_time     = models.DateTimeField(auto_now_add=True, null=True)
    gov_crawled_status      = models.BooleanField(default=False)
    gov_ocr_status          = models.BooleanField(default=False)
    is_shareholders_confirm = models.BooleanField(default=False)
    is_all_ner_finished     = models.BooleanField(default=False)

    # person_application    --> class Person, null=True
    # comp_application      --> class Company, null=True
    # gov_docs_crawling     --> class GovDoc as a set, null=True
    # shareholders          --> class Person as a set, null=True

    class Meta:
        app_label = 'VBService'


class GovDoc(models.Model):
    doc_name            = models.CharField(default='', max_length=254)
    record_created_time = models.DateTimeField(auto_now_add=True,null=True)
    doc_file_location   = models.CharField(default='', max_length=254)
    ocr_output_location = models.CharField(max_length=254, null=True)
    ocr_status          = models.IntegerField(default=0)

    overall_process     = models.ForeignKey(OverallProcess,
                                            related_name='gov_docs_crawling',
                                            on_delete=models.CASCADE,
                                            null=True)

    class Meta:
        app_label = 'VBService'