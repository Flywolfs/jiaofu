import json
from django.http import HttpResponse
from ..models import OverallProcess
import datetime
from json2html import *
import pdfkit
from VBService.views import static_path

# Inner API2
def receive_ocr_result(request):
    # TODO load json in request
    if request.method != 'POST':
        print('--- failed here ---')
        return HttpResponse('Bad Request')
    var = json.loads(request.body.decode())
    print('--- load json ---')

    if 'session_id' in var and 'doc_name' in var and 'ocr_status' in var:
        print("接收到OCR分析结果")
        session_id = var['session_id']
        doc_name = var['doc_name']
        ocr_status = var['ocr_status']
        ocr_output_location = var['ocr_output_location']
        OverallProcess.objects.get(session_id=session_id).gov_docs_crawling \
            .filter(doc_name=doc_name).update(ocr_status=ocr_status, ocr_output_location=ocr_output_location)
        # TODO determine whether 'gov_ocr_status' should be update here?
        OverallProcess.objects.filter(session_id=session_id).update(gov_ocr_status=True)
        op = OverallProcess.objects.get(session_id=session_id)
        comp_en_name = op.comp_application.en_name
        docs = op.gov_docs_crawling.all()
        # generate compliance file for comp with NAR1
        compliance_check = {"session id":session_id,"start time":str(op.record_created_time)+" UTC Time",
                     "end time":str(datetime.datetime.now())+" Hongkong Time","icris ocr file record":[]}
        for doc in docs:
            compliance_check["icris ocr file record"].append({"filename":doc.doc_name,"path":doc.ocr_output_location})
        html = json2html.convert(json=compliance_check)
        pdfkit.from_string(html, static_path.full_gov_path+comp_en_name+'/compliance_check.pdf')
        return HttpResponse('Succeed to save ocr file')
    else:
        return HttpResponse('Bad Request')
