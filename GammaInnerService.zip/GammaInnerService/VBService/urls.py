from django.urls import path
from .views import api1, api2, api3, api4

urlpatterns = [
    path(r'crdownloadresult/', api1.receive_cr_result, name="check_company_num"),
    path(r'ocrresult/', api2.receive_ocr_result, name="receive_ocr_result"),
    path(r'negresult/', api3.receive_neg_result, name="receive_neg_result"),
    path(r'nerresult/', api4.receive_ner_result, name="receive_ner_result")
]